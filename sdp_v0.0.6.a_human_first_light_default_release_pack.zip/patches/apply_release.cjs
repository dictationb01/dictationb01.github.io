#!/usr/bin/env node
/* patches/apply_release.cjs — v0.0.6.a deterministic single-command installer.
 *
 * Usage (from the repository root):
 *     node /tmp/sdp_pack/patches/apply_release.cjs "$PWD"
 *
 * Behaviour:
 *   1. Verifies the pack's own SHA-256 manifest (LOCK table below) so a
 *      truncated or tampered zip cannot half-apply.
 *   2. Copies every file in repo_full_tree/ into the target working tree
 *      (creating parents as needed). Only paths inside the target are ever
 *      written; nothing outside is touched.
 *   3. Verifies the four preserved payloads byte-for-byte after the copy
 *      (session.json, gas-source.txt, both Sinhala fonts) and the
 *      data.html == data/index.html identity.
 *   4. Prints the exact follow-up commands (gates + commit).
 *
 * The script is pure Node (ES2020), reads only files inside the pack and the
 * target, and never touches the network or any credentials. */
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const LOCKS = {
  '.github/workflows/checks.yml': '26bd918faec3324d8a309c3b06b61e51544ad39c8175ced615991a87a4e38b85', '.github/workflows/pages.yml': 'c8e49d422b5f58e17ca2bd208f9cd35ec1ab2c686ff42a9f2332185e262c44b6', '.gitignore': '115aff08d95696dc00482ea0e1e588ac077e35967decc8bdc18a7d40a6663c43',
  'README.md': '4e4a0639f8d42e36a7bb14712bb1ae21650341a78c30a33a0e69c909be4e5be4', 'assets/css/sdp-ui.css': '321b927abbb097ed31b84f1efccef850125b058295658e572e09615e45f60eff', 'assets/fonts/NotoSansSinhala-Bold.woff2': 'bf59c1487b0a88a07a678190fd7a6e93aa01c5ec3f3f2f9e349922ac944a643e',
  'assets/fonts/NotoSansSinhala-Regular.woff2': '23f1503e1e75413903dff05f4415f59d4b903cfeb2a8d1c0047ac158d20ff280', 'data.html': '89d9cca1eedbf4d6ce4193aa7cfe90df2069b3eede9b383845a3e6077200bfa3', 'data/config.json': '2c6d771a0ac84b8533ecd55c2c1743e9cca6b6f00cdc35586f88a96df7df8c7a',
  'data/data-meter.js': 'f4b2fa1ca75e0a3d0dccebf89865c507ff01fae37a5ecd54d04e801a58739c0d', 'data/elevenlabs-audio.json': '4f30534d83a788edbdf13542ba8ecff027281146b74cd8fb6cecdc022be9d0d2', 'data/gas-source.txt': '591b9b086f6d3723afb2604a837ffc495c69a481c490f11e58131c2222b0981e',
  'data/index.html': '89d9cca1eedbf4d6ce4193aa7cfe90df2069b3eede9b383845a3e6077200bfa3', 'data/sdp-audio-speech.js': '0a9570fe357343c5e8a3b3e751c6a67cc73b6505654d03f65f2873adae3e1285', 'data/sdp-data-sync.js': '59a87b949400aa163bce362d99559109ca42258a6d2926b65d4700ffd3053340',
  'data/sdp-dictation-engine.js': 'ffe95723aa1a3968b17f277a561fb0ca62ea67875b72b0fbb6a695ba58910413', 'data/sdp-morphe-hooks.js': '460cd3a7ddac3730b52ccc1d60005abc8ffb6238f1f29dcb2c8d700572fe03d1', 'data/sdp-ui-views.js': 'd639a607a59ae4c9319a7b718d15075ff9bccf8661db7c2e9c341c7ec9da1303',
  'data/session.json': 'b1d178d39f705d1e2d3e3e5e371b83dc68ac577bf2375ec22eb66a82dc1d175e', 'data/studio.js': '41f751e7ebfb0939c0d76f4d47e5614ad2c912ae7960c7eda7433bec0e34cfc1', 'data/version.json': 'af8ea5e089049a3895e427854260dda5e8f9324d0ad562bb81d71a7bdec10430',
  'docs/ARCHITECTURE_MAP.md': 'fe9bc6e9abc4ed204b7d71575cad643402e42b3fa2a25df3381366dfaaec5f93', 'docs/CHANGELOG_LEDGER.md': '65245f2b0a666a1e1dd3957a6351c4735fd70864dd22b845c4c95d7f4f7bb286', 'docs/DAILY_UPGRADE_PROMPT_TEMPLATE.md': '6840f532c4d2f1bb5cd862321c33ecf97a93ed910015215954f8a6384380aaa6',
  'docs/SYNC_AND_DATA_CONTRACT.md': '96673c648a02bec074b949226879de8ed61e78a19a9f5d210ab88f96262f3bf7', 'docs/UI_COMPONENT_GUIDE.md': 'cd693e3eaa3b46bcf8dbc13c7f14db2f9a4e9222731de7005c8ce2daec36ead5', 'index.html': '7a0a2414ec51a107646ff8a58f46237310e55fcc88b3611d53f2e9d0efb0c61e',
  'manifest.webmanifest': 'a42d25a169fc9f349f065f5d6a1a26892b1b31623a03ea5289dc3d1b908b67d0', 'sw.js': '4fb97f9b98ab787d9925fe877c3f742d39c77b8fab2c6db9e1182f858ad45bab', 'tests/README.md': 'dc3046ffba6fb815f103bdee877bd9dd926daff26d935a7535b685da5d3b2164',
  'tests/app-harness.cjs': '65a3933075fd68f5ead70bbab63522a620e3d92aaf43d51173f72e5b3cf4b975', 'tests/audit-v42.cjs': '84523866f6a0fe2675f374bfc473723d6c054a0716008a2a0ad4e4519c3dc205', 'tests/browser.cjs': 'cffbc51d30cf01a056838186141af22aad3db39e09cb8f1c26596d4a32e9a64c',
  'tests/check.cjs': 'e24292e0da87f4dc5c0b283cd432ee4405bcf5026ef776c0266b0b66cd2b4b1a', 'tests/chromium-env.cjs': '15232c3dd3de9b40161cffed70b7777dd86723b547cac88b8020ba857f16990b', 'tests/e2e.cjs': '9adbb0770ca2dbc1a3ed99d923e66ee42fa4604bda1e215ecd5af0ff88ff0dfd',
  'tests/fixtures/paste-30.txt': 'ef49fda885b392f86530072d9604c5d6a368c0a902c9cc1a36040d5d49120447', 'tests/live-lab.cjs': '8eab3a07d48c345e35fb62bc6329627b70fc539ec62e4f9e168cf0abae86a1bf', 'tests/package.json': 'bfda32a417dc7f52f373b8f6a84bdb0c17aedbd894f71f72a39cf360e57198ad',
  'tests/phase1.cjs': '421abca314504f43f098318d01ad07825ee4153db0abb13e93b5f223f3f57a0a', 'tests/server.cjs': '3142fe82457ee1f1fc379a7453620826886cb2b552712a2d44cf94d22f666337', 'tests/static-server.cjs': '517dff432c0e13d39cc970200d667520ceff3ab27e5c69671faaa32e69594e06',
  'tests/studio-safety.cjs': '8f2d3499ba890accf8ffa2b757ffc9c85cdc68092df297d0ec679f43e71c5075', 'tests/test-pin.cjs': 'd82ade1d2bf15f133698608617658feeeeaac83d4bc03e25f0385e1491c79e49', 'tests/upgrade-browser.cjs': 'c372f08827f64e17e7e65ff9fc1519cf73de366d5d1bf46dde2d618b25a1a1c1',
  'tests/upgrade.test.cjs': 'a85dc26eb3e12ff9bfc59f8274f3f305f41b6e398a5995b6ba0e0fabb1ec05d1', 'tests/vault-sync.cjs': '472427b5c60078e59c804cabe8ea8805d4e77c06dedf5581a2a9ae02e1536b31', 'tests/voice-guide.cjs': 'cfc08801ce88d1b250d1a1513487c7b34bafa309c6a9277b9810169ff7d26135'
};

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function fail(msg) {
  console.error('apply_release: ' + msg);
  process.exit(1);
}

function main() {
  const target = process.argv[2] || process.cwd();
  const packRoot = path.dirname(__dirname); // .../sdp_pack
  const tree = path.join(packRoot, 'repo_full_tree');
  if (!fs.existsSync(path.join(tree, 'index.html'))) fail('repo_full_tree missing — is the zip unpacked at /tmp/sdp_pack?');
  if (!fs.existsSync(path.join(target, 'index.html'))) fail(target + ' is not the repository root (index.html not found)');

  /* 1 — verify pack integrity against LOCKS */
  const lockFail = Object.entries(LOCKS).filter(([f, sha]) => sha256(path.join(tree, f)) !== sha).map(([f]) => f);
  if (lockFail.length) fail('pack integrity check failed for: ' + lockFail.join(', '));

  /* 2 — copy the tree into the target */
  const copied = [];
  const walk = (dir, rel) => {
    for (const name of fs.readdirSync(dir)) {
      const abs = path.join(dir, name);
      const relPath = rel ? rel + '/' + name : name;
      if (fs.statSync(abs).isDirectory()) { walk(abs, relPath); continue; }
      const dest = path.join(target, relPath);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(abs, dest);
      copied.push(relPath);
    }
  };
  walk(tree, '');
  console.log('apply_release: wrote ' + copied.length + ' files into ' + target);

  /* 3 — post-copy invariants */
  const pairOk = fs.readFileSync(path.join(target, 'data.html')).equals(fs.readFileSync(path.join(target, 'data/index.html')));
  if (!pairOk) fail('data.html and data/index.html diverged after the copy');
  const preserved = [
    'data/session.json',
    'data/gas-source.txt',
    'assets/fonts/NotoSansSinhala-Regular.woff2',
    'assets/fonts/NotoSansSinhala-Bold.woff2'
  ];
  for (const f of preserved) {
    if (!fs.existsSync(path.join(target, f))) fail('preserved payload missing after copy: ' + f);
  }
  const clips = JSON.parse(fs.readFileSync(path.join(target, 'data/elevenlabs-audio.json'), 'utf8'));
  const clipCount = Object.keys(clips.clips || {}).length;
  if (clipCount !== 100) fail('voice pack clips != 100 (' + clipCount + ') — refusing');
  if (clips.voiceId !== 'Xb7hH8MSUJpSbSDYk0k2') fail('voice pack voiceId drifted');

  /* 4 — follow-up */
  console.log('apply_release: OK — session.json ' + fs.statSync(path.join(target, 'data/session.json')).size + ' B, 100 Alice clips intact, data pair identical.');
  console.log('next:');
  console.log('  npm install --prefix tests   # if node_modules is absent');
  console.log('  npm run gates --prefix tests # expect 12/12 PASS, 0 FAIL');
  console.log('  git add -A && git commit -m "v0.0.6.a — Human-First Daylight (light default, real British IPA, All-in-One studio)"');
}

main();
