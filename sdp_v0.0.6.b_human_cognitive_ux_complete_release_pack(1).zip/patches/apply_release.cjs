#!/usr/bin/env node
'use strict';
/* Smart Dictation Player v0.0.6.b (regression-fix release) — deterministic installer.
 * Usage: node apply_release.cjs <repo-root>
 * Unpack the release zip to /tmp/sdp_pack first (see ARENA TC2). */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PACK = __dirname;
const ROOT = process.argv[2] || process.cwd();
const FILES = [
  ".github/workflows/checks.yml",
  ".github/workflows/pages.yml",
  ".gitignore",
  "README.md",
  "assets/css/sdp-ui.css",
  "assets/fonts/NotoSansSinhala-Bold.woff2",
  "assets/fonts/NotoSansSinhala-Regular.woff2",
  "data.html",
  "data/config.json",
  "data/data-meter.js",
  "data/elevenlabs-audio.json",
  "data/gas-source.txt",
  "data/index.html",
  "data/sdp-audio-speech.js",
  "data/sdp-data-sync.js",
  "data/sdp-dictation-engine.js",
  "data/sdp-morphe-hooks.js",
  "data/sdp-ui-views.js",
  "data/session.json",
  "data/studio.js",
  "data/version.json",
  "docs/ARCHITECTURE_MAP.md",
  "docs/CHANGELOG_LEDGER.md",
  "docs/DAILY_UPGRADE_PROMPT_TEMPLATE.md",
  "docs/SYNC_AND_DATA_CONTRACT.md",
  "docs/UI_COMPONENT_GUIDE.md",
  "index.html",
  "manifest.webmanifest",
  "sw.js",
  "tests/README.md",
  "tests/app-harness.cjs",
  "tests/audit-v42.cjs",
  "tests/browser.cjs",
  "tests/check.cjs",
  "tests/chromium-env.cjs",
  "tests/e2e.cjs",
  "tests/fixtures/paste-30.txt",
  "tests/live-lab.cjs",
  "tests/package-lock.json",
  "tests/package.json",
  "tests/phase1.cjs",
  "tests/server.cjs",
  "tests/static-server.cjs",
  "tests/studio-safety.cjs",
  "tests/test-pin.cjs",
  "tests/upgrade-browser.cjs",
  "tests/upgrade.test.cjs",
  "tests/vault-sync.cjs",
  "tests/voice-guide.cjs"
];
const LOCKS = {
  ".github/workflows/checks.yml": "26bd918faec3324d8a309c3b06b61e51544ad39c8175ced615991a87a4e38b85",
  ".github/workflows/pages.yml": "c8e49d422b5f58e17ca2bd208f9cd35ec1ab2c686ff42a9f2332185e262c44b6",
  ".gitignore": "115aff08d95696dc00482ea0e1e588ac077e35967decc8bdc18a7d40a6663c43",
  "README.md": "4e4a0639f8d42e36a7bb14712bb1ae21650341a78c30a33a0e69c909be4e5be4",
  "assets/css/sdp-ui.css": "40cbc87052b120a4e5ab922594e0901acf9cb36276925e332e3fb870cdb85d56",
  "assets/fonts/NotoSansSinhala-Bold.woff2": "bf59c1487b0a88a07a678190fd7a6e93aa01c5ec3f3f2f9e349922ac944a643e",
  "assets/fonts/NotoSansSinhala-Regular.woff2": "23f1503e1e75413903dff05f4415f59d4b903cfeb2a8d1c0047ac158d20ff280",
  "data.html": "e7288f106a0f3fa524e085d119f553a6ebae9b7f527302998376685418c340fc",
  "data/config.json": "28e6c4c41dd370c54da07b215b387e06f584e2a96e890f76bbe1973e11536aa7",
  "data/data-meter.js": "ffd3c6f5ffd7b9848433548801ecf8de762d6610ff12260b726e51800b5dd127",
  "data/elevenlabs-audio.json": "03c2de8ae9cdaed40ee9288429d6c3c0be0b0ab315149ea6d53f96b0c02f72d5",
  "data/gas-source.txt": "591b9b086f6d3723afb2604a837ffc495c69a481c490f11e58131c2222b0981e",
  "data/index.html": "e7288f106a0f3fa524e085d119f553a6ebae9b7f527302998376685418c340fc",
  "data/sdp-audio-speech.js": "0a9570fe357343c5e8a3b3e751c6a67cc73b6505654d03f65f2873adae3e1285",
  "data/sdp-data-sync.js": "69cdf239edf154c4f1924225b48f2e89d28725739e9229e5b1ab35606a9a4b34",
  "data/sdp-dictation-engine.js": "ffe95723aa1a3968b17f277a561fb0ca62ea67875b72b0fbb6a695ba58910413",
  "data/sdp-morphe-hooks.js": "460cd3a7ddac3730b52ccc1d60005abc8ffb6238f1f29dcb2c8d700572fe03d1",
  "data/sdp-ui-views.js": "390adb8293c089be27a6668c4b1ba8b172506372e5681ecd1d630deff22a217c",
  "data/session.json": "b1d178d39f705d1e2d3e3e5e371b83dc68ac577bf2375ec22eb66a82dc1d175e",
  "data/studio.js": "29df9134c0ef2e5cb64c086746814102538eea332942eb91c63fe9b7f8559431",
  "data/version.json": "4aaf3bf4ba1f69439d718b2126f9d473015544e4938628e76927b7f7387f9510",
  "docs/ARCHITECTURE_MAP.md": "fe9bc6e9abc4ed204b7d71575cad643402e42b3fa2a25df3381366dfaaec5f93",
  "docs/CHANGELOG_LEDGER.md": "65245f2b0a666a1e1dd3957a6351c4735fd70864dd22b845c4c95d7f4f7bb286",
  "docs/DAILY_UPGRADE_PROMPT_TEMPLATE.md": "6840f532c4d2f1bb5cd862321c33ecf97a93ed910015215954f8a6384380aaa6",
  "docs/SYNC_AND_DATA_CONTRACT.md": "96673c648a02bec074b949226879de8ed61e78a19a9f5d210ab88f96262f3bf7",
  "docs/UI_COMPONENT_GUIDE.md": "cd693e3eaa3b46bcf8dbc13c7f14db2f9a4e9222731de7005c8ce2daec36ead5",
  "index.html": "a0ff5b0c6281b56c62a1acfc289b265e449e8bcb3f281f970250bbdf784687cc",
  "manifest.webmanifest": "4219085f4de440515654217faee56d6840575de2f92caac1d12c0730d4b23550",
  "sw.js": "b1f8a150758b650093acbaba6aeb4031caf4d9466a0eb30f74e775c88204911f",
  "tests/README.md": "dc3046ffba6fb815f103bdee877bd9dd926daff26d935a7535b685da5d3b2164",
  "tests/app-harness.cjs": "65a3933075fd68f5ead70bbab63522a620e3d92aaf43d51173f72e5b3cf4b975",
  "tests/audit-v42.cjs": "eeefce1314eafda3a0dc796efb5ceae9b51eb8d87fde251e2cd52f6cf7f0802a",
  "tests/browser.cjs": "7d3b1fa03b8081e0509364c673b0c6bff5fadd71360aa4c0644af1a49ebb536a",
  "tests/check.cjs": "6130fda23d41d463c04d08e3e8f688b043e42606ed80c05d93315d6df9772e5a",
  "tests/chromium-env.cjs": "15232c3dd3de9b40161cffed70b7777dd86723b547cac88b8020ba857f16990b",
  "tests/e2e.cjs": "4b16e77bbcc4154ec3173074aef746fb0624a6e94246162c67cbbe7e4427521a",
  "tests/fixtures/paste-30.txt": "ef49fda885b392f86530072d9604c5d6a368c0a902c9cc1a36040d5d49120447",
  "tests/live-lab.cjs": "8eab3a07d48c345e35fb62bc6329627b70fc539ec62e4f9e168cf0abae86a1bf",
  "tests/package-lock.json": "eb3ebf8b9bc6ac0d26f45644e82a90d905c0067c525cd5daf882f8341fe7c499",
  "tests/package.json": "bfda32a417dc7f52f373b8f6a84bdb0c17aedbd894f71f72a39cf360e57198ad",
  "tests/phase1.cjs": "7764735e50dde05401715e937931fe76a0c5ed12b1218463b84058fbbc40fac0",
  "tests/server.cjs": "23357a82921516ce5e4a17fed5bd0c4584eda883b4f4b3e67dc04d1cf3ee681c",
  "tests/static-server.cjs": "517dff432c0e13d39cc970200d667520ceff3ab27e5c69671faaa32e69594e06",
  "tests/studio-safety.cjs": "83c0a6eef9d3730c3fd6d0051f0a40c273bf029e80a193236333ac64c96892d1",
  "tests/test-pin.cjs": "d82ade1d2bf15f133698608617658feeeeaac83d4bc03e25f0385e1491c79e49",
  "tests/upgrade-browser.cjs": "67f84d3edbe41dab4ffa92cada1d9cbf31be66aa76588c1ffc5592d1ae99c199",
  "tests/upgrade.test.cjs": "f5c9c9c148c1e3fc27669a58df8ff2d424acb34b53c0fbb7b85593d69a6e4a40",
  "tests/vault-sync.cjs": "ef99cb262e843252b8541641e6fe620f7e7089a79f351822504df060cfb62d6c",
  "tests/voice-guide.cjs": "2d6aa6541498ea5ffcb369f6634e08f9ff18c0a21d721ad368a8af0086f4b188"
};
let fail = 0;
for (const rel of FILES) {
  const src = path.join(PACK, '..', 'repo_full_tree', rel);
  let buf;
  try { buf = fs.readFileSync(src); } catch (e) { console.log('MISSING ' + rel); fail++; continue; }
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  if (sha !== LOCKS[rel]) { console.log('SHA MISMATCH ' + rel); fail++; continue; }
  const dest = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, buf);
}
console.log(fail === 0 ? 'apply_release: ' + FILES.length + ' files installed, 0 failures' : 'apply_release: ' + fail + ' failures');
process.exit(fail ? 1 : 0);
