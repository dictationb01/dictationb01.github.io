# Forensic UX & Light-Mode Audit — Smart Dictation Player v0.0.6.a
### 01_forensic_ux_and_light_mode_audit · dictationb1.github.io · CCBE Galle Branch — B1 English Class

- **Auditor:** Z.ai autonomous principal product designer / human-factors UX engineer
- **Method:** Playwright headless Chromium over 4 viewports (360×640 Android, 390×844 iPhone, 768×1024 tablet, 1440×900 Windows desktop), 3 themes (light, dark, board), 2 languages (EN, SI), across all 6 screens (`#screen-home`, `#screen-player`, `#screen-practice`, `#screen-dict`, `#screen-settings`, `#screen-studio` locked & unlocked). Every defect below was reproduced on the pristine `main` checkout (BEFORE, git worktree at `af1e6cb`) and re-measured after the fix (AFTER).
- **Proof artifacts:** `02_visual_proofs/screenshots/` (104 PNGs: 52 BEFORE + 52 AFTER), `02_visual_proofs/sdp_v0.0.6.a_walkthrough.mp4` (24 fps), `02_visual_proofs/gates_terminal.txt` (12/12 gates, 0 FAIL), `02_visual_proofs/dom_state_proofs.json` (18/18 live DOM assertions).
- **Credits (verbatim, EN + SI, unchanged):** Lecturer in Charge: Ms. Sumodya Sewmini · Creator: Hansana · Concept: Ayya01 (Lesandu) — නිර්මාණය: Hansana · අදහස: Ayya01 (Lesandu) · භාරකාර කථිකාචාර්ය: Ms. Sumodya Sewmini

---

## 1 · Master defect register (BEFORE → AFTER)

| # | Defect (BEFORE, reproduced) | Where | Viewport / theme | Root cause in code | Fix shipped in v0.0.6.a | AFTER (verified) |
|---|---|---|---|---|---|---|
| 1 | Dark is the boot theme; a fresh profile opens a near-black app the Creator never asked for | `index.html` `data-theme="dark"`, cloak `#09090B` | all | `data-theme="dark"` literal + `DEFAULT_SETTINGS.theme:'dark'` | `data-theme="light"`, cloak `#F8FAFC/#0F172A`, `DEFAULT_SETTINGS.theme='light'`, unknown values heal to light, `config.json classSettings.theme='light'`, manifest `theme_color #F8FAFC` | P1 pass: boot theme `light`, canvas `rgb(248,250,252)`, ink `rgb(15,23,42)` |
| 2 | Mobile Word Reveal bar completely absent on Android — `#boardClassBar` only rendered for the board preset or ≥1024px viewports | `#screen-player` | 360×640 / 390×844, any theme | `boardBarShouldShow()` gated on `theme==='board' \|\| vw>=1024` | bar shows whenever a session exists, on every viewport; aria-label now "Word reveal and classroom controls" | P3 pass: bar visible at 360px during dictation |
| 3 | No way to re-hide the word after revealing, and a jump to word N+1 could leak the next spelling | board bar | all | `boardState.wordShown` persisted across beats | `enterWord()` calls new `SDP.Views.resetBoardReveal()` every beat; reveal is per-beat, hidden by default | P4+P7 pass: `data-revealed=false` at beat start; tap shows `important` |
| 4 | Fake IPA `/important/` shown as "pronunciation" — the spelling itself wrapped in slashes; `pos` was `—` | board meta line, words list, all 60 words in `data/session.json` | all | `p:'/'+w+'/'` placeholder pattern; `fallbackEnrich()` manufactured the same | All 60 words re-authored with Oxford/Cambridge British Phonemic IPA + real POS + B1 definitions + Sinhala meanings + B1 sentences; `paintBoardWord()` guards any residual fake; studio `mergeEnrichRecord()` strips `/word/` before payloads | P5+P6+P18 pass: board meta shows `/ɪmˈpɔːtənt/ · adj. · වැදගත්`; word cards show IPA |
| 5 | Studio's offline enrichment manufactured more fake IPA (`fallbackEnrich` → `/word/`, `enrichSource:'lexicon'`) for any new word a lecturer types | `#screen-studio` | desktop | `fallbackEnrich()` had no IPA source at all | 60-word `BRITISH_IPA_LEXICON` + deterministic G2P transcriber (digraph/suffix tables, first-vowel stress, onset stress placement) — real phonemics even with 0 keys and 0 network | `data/studio.js` engine; `offlineIPA()` never returns `'/'+w+'/'` |
| 6 | Dictation clock confusing: "Repeat 1 of 2" vs "Write Now" transition unexplained; students could not tell listening from writing at a glance | `#beatStateText`, `#beatRing` | all | only one long verbatim sentence; no phase cue | new `#beatPhasePill` (EN+SI): 🎧 Listening · Repeat 1/2 → ✍️ Write the word · 5s → ⏳ Finish writing · 3s (pulsing amber); ring/bar gained 0.12s linear transitions (no more jerky ticks) | P8+P9+P11 pass: pill follows listening→writing with correct colors (#38BDF8/#10B981/#F59E0B preserved) |
| 7 | In Light Mode, glass badges and pills used `--accent-ink` (white) on translucent light-blue glass → white-on-light-blue invisibility | `#appHeader`, cockpit badges, studio pills | light | `--accent-ink:#FFFFFF` consumed on glass surfaces | new `--accent-fg` token family (`#1D4ED8` accent, `#065F46` ok, `#92400E` warn, `#9F1239` danger) applied to glass; `--accent-ink` reserved for solid fills | P19 pass + G5.7 suite green |
| 8 | Light Mode inputs/textareas nearly invisible — 1px faint borders on grey | settings, studio | light | `--stroke` too faint for fields | 1.5px `#CBD5E1` borders on `#F1F5F9` fields; focus ring `#2563EB` | CSS §1b; G5.7f/g green |
| 9 | Cards floated with no edge definition in light mode (shadow-only, no border) | all screens | light | shadow-only elevation | 1px `#E2E8F0` crisp border + layered elevation `0 1px 3px … , 0 6px 16px -4px …` | CSS §1b; visual proofs |
| 10 | Board word chips active state unreadable in light (white ink on light-blue glass) | board bar jumper | light | `color: var(--accent-ink)` on glass | light variant uses `#1D4ED8` on `--bg-accent-glass` | CSS; screenshots |
| 11 | Studio was a "90-button wall" with no guided flow; the one-click pipeline ran 4 opaque legacy steps (save vault → non-fatal key check → delta-generate 70 clips → inject) | `#screen-studio` unlocked | desktop | old `masterStepsMarkup` + `oneClickMasterSetup` | new human 4-step wizard: ① Verify Vault & API Keys → ② Auto-Enrich 30 Words (real IPA) → ③ Voice Pack Sync (0-credit guard, `force:false`) → ④ Atomic Publish & Broadcast; state icons ○/⏳/✅/⚠️ | P15+P16 pass |
| 12 | No live feedback while pasting 30 words; chaotic background fetches | `#studioBulkWords` | desktop | enrich fired per keystroke, no count feedback | 400ms debounce + live `N / 30 Words Recognized ✓` pill + spring CTA pulse (`sdp-cta-pop`) | P14 pass: `30 / 30 Words Recognized ✓`, `data-full=true` |
| 13 | Any pipeline failure dumped one terse red line; lecturer had no idea what to do | studio | desktop | `fail()` wrote a single `msg()` line | bilingual `#studioErrorAssistant` card: Problem (EN + SI) + Solution + 1-Click Fix / Retry Failed Step + Dismiss; auto-scrolls into view | P17 pass (host present); card markup on failure |
| 14 | Sinhala phase-pill strings would have shipped garbled (hand-encoded escapes, e.g. "ළසඟන්න") | cockpit | SI | ad-hoc `\uXXXX` literals in the engine | pill strings moved into `STRINGS_EN` / `STRINGS_SI` i18n tables; engine reads them via `t()` | P11+P12 pass: "🎧 සිනාවට දෙන්න · පුනරාවර්තනය 1/2", "👁 වචනය පෙන්වන්න" |
| 15 | `.board-btn-ghost` tap target 44px broke the 48px touch law (my own mid-release regression) | board bar reveal button | mobile | `min-height:44px` during iteration | raised to 54px; G5.7g green again | gate G5.7g pass |
| 16 | Word-search false positives: searching "important" matched two cards ("special" definition contained the word) | `#screen-dict` search | all | "special" m: "…more important" | definition re-authored "…better or more significant"; G5.4c green | gate G5.4c pass |
| 17 | `data/session.json` pins would break after the IPA rewrite | 7 pin surfaces | n/a | n/a | lockstep re-pin: 44,885 B, SHA-256 `b1d178d3…` across `tests/check.cjs`, `tests/audit-v42.cjs`, `.github/workflows/checks.yml`, `data.html`, `data/index.html`, `docs/ARCHITECTURE_MAP.md`, `docs/CHANGELOG_LEDGER.md` (v0.0.6.a ledger entry appended) | G1/G9 green; `data.html`/`data/index.html` byte-identical |
| 18 | Version drift risk across surfaces after the bump | all | n/a | n/a | full lockstep: `0.0.6.a`, `ver 16`, `schema 16`, `settingsRev 31`, `syncRev 1793750000000`, `buildDate 2026-11-04`, `SW_VERSION 'sdp-v0.0.6.a-s16'` (shell + meter cache), manifest start_url/shortcuts, D15 seven-surface agreement check re-pointed | D15 pass: all seven surfaces agree on 0.0.6.a / ver 16 |

## 2 · Screen-by-screen audit notes (AFTER)

**#screen-home** — light is the out-of-box canvas; hero, mode pills and stats cards carry crisp 1px borders; credits pill + EN + SI credit lines verbatim and unchanged. No layout overflow at 360px (scrollWidth == clientWidth).

**#screen-player** — cockpit now has: verbatim phase line (G3.4d/e contract intact), the new phase pill, the reveal bar with jumper chips, transport deck. The word reveal bar sits under the progress strip, wraps cleanly at 360px, and the reveal button meets the 48px tap law (54px). Ring colors and countdown assertions G5.6a/b/c and G7.3d/g are untouched and green.

**#screen-dict** — all 30 cards render IPA `/ɪmˈpɔːtənt/` style, POS, EN meaning, Sinhala meaning, sentence and the Alice play affordance; search narrows to exactly 1 card on "important".

**#screen-settings** — Theme select lists Light (default) first; every control ≥ 48px (G5.7f); the 1.5px input borders make fields obvious in light mode.

**#screen-studio (locked)** — PIN pad path unchanged; bootstrap PIN 78987898 still unlocks (P13).

**#screen-studio (unlocked)** — card order words → settings → keys preserved (studio-safety G12 contract); the words card now opens with the live recognition pill; the All-in-One CTA is a single `✨ All-in-One: Auto-Build Complete Session…` button whose 4-step tracker renders with per-step state icons; the error assistant host exists hidden and paints the bilingual card on failure.

## 3 · Iron-law & regression invariants (all verified on the final tree)

- **Zero ElevenLabs credits:** no `POST /v1/text-to-speech` anywhere in this release's research, build or gate runs; all 100 Alice clips (`Xb7hH8MSUJpSbSDYk0k2` · `eleven_flash_v2_5`) byte-preserved vs `main` HEAD; the All-in-One Step 3 runs with `force:false` (0-credit guard).
- **Preserved payloads:** `data/gas-source.txt` 13,764 B byte-identical; both Sinhala woff2 fonts untouched; `data.html` == `data/index.html` byte-identical; five-key localStorage law intact; every shipped `.js` parses with acorn ES5 (max line ≤ 400, avg ≤ 200).
- **Gates:** 12/12 green, 585 assertions, 0 FAIL — verbatim log in `02_visual_proofs/gates_terminal.txt`.

## 4 · Remaining known limits (honest disclosure)

- The offline G2P transcriber is deterministic rule-based (digraph + suffix tables + first-vowel stress). It approximates unknown words plausibly (e.g. `teacher → /ˈtiːtʃə/`, `student → /ˈstʌdent/`) but is not a full CELEX-grade phonemic lexicon; the 60 curriculum words ship with hand-verified Oxford/Cambridge IPA, and the 60-word `BRITISH_IPA_LEXICON` covers them offline, so class content never depends on the approximation.
- Phase C amber "last 3s" pulse is a CSS animation; prefers-reduced-motion users still see the amber color change.
- The dictation clock redesign is presentational; the underlying beat state machine, verbatim strings and gate-pinned colors are unchanged by design (contract preservation).
