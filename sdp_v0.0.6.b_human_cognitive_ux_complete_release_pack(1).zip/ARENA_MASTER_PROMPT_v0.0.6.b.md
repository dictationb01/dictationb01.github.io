# Arena Master Prompt — Smart Dictation Player v0.0.6.b Regression-Fix Release Merge

You are the Arena release agent for `dictationb1/dictationb1.github.io`. This pack ships the v0.0.6.b Human-Cognitive UX release with all six critical regressions (M1–M6) fixed and re-verified: scope-safe Light-default migration that never overrides an explicit Dark/Board choice, clean unescaped studio button labels, a single calm Lecturer security bar with the word inspector folded away, corrected Sinhala strings, the 2×2 Settings preset grid with 48px −/+ steppers, and a Sinhala-clean audit PDF (embedded Noto Sans Sinhala). Version lockstep `0.0.6.b` (ver 17, schema 17, settingsRev 32, syncRev 1793760000000). Execute the four task cards in order; stop and report if any gate fails.

## TC1 — Fetch, unpack, and clean the working tree

1. `git fetch origin main`
2. Unpack `sdp_v0.0.6.b_human_cognitive_ux_complete_release_pack.zip` from the repo root to `/tmp/sdp_pack`: `unzip -o sdp_v0.0.6.b_human_cognitive_ux_complete_release_pack.zip -d /tmp/sdp_pack`
3. Remove every zip from git AND disk so G1 (no unbudgeted shipped files) passes: `git rm -f '*.zip' 2>/dev/null || true; rm -f *.zip`

## TC2 — Install the release deterministically

Run the SHA-256-locked installer (49 files, all hashes verified before write):

```
node /tmp/sdp_pack/patches/apply_release.cjs "$PWD"
```

It must print `apply_release: 49 files installed, 0 failures` and exit 0. Any `MISSING` or `SHA MISMATCH` line means the pack is corrupt — stop and report.

## TC3 — Run the 12 release gates

```
npm install --prefix tests --no-audit --no-fund
npm run gates --prefix tests
```

Expected: all 12 gates green with 0 FAIL — G1 check (110), G2 upgrade.test (12), G3 phase1 (102), G4 server (68), G5 browser (60), G6 upgrade-browser (15), G7 e2e (52), G8 live-lab (39), G9 audit-v42 (47), G10 voice-guide (38), G11 vault-sync (74), G12 studio-safety (94) — 711 assertions total. Zero ElevenLabs credits are spent: the suite never calls `/v1/text-to-speech/` and all 100 Alice clips are byte-preserved.

## TC4 — Commit, push, PR, and merge in this turn

```
BRANCH=$(git rev-parse --abbrev-ref HEAD)
git add -A
git commit -m "v0.0.6.b — regression-fix release: scope-safe theme migration, clean studio labels, calm unlocked studio, 2×2 settings grid (12/12 gates)"
git push -u origin "$BRANCH"
gh pr create --base main --head "$BRANCH" --title "v0.0.6.b Regression-Fix Release (12/12 gates, 0 FAIL)" --body "M1-M6 fixed: true Dark/Board themes, no &amp; double-escape, single Lecturer security bar + collapsible word inspector, corrected Sinhala strings, 2×2 preset grid, embedded-font bilingual PDF. gates_terminal.txt in the release pack."
gh pr merge "$BRANCH" --merge --delete-branch
```

All four steps must happen in this same turn; report the PR URL when merged.
