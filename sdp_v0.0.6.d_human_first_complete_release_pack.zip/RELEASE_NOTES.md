# Smart Dictation Player v0.0.6.d — Human-First Complete Release Pack

Version lockstep: 0.0.6.d · ver/schema 19 · settingsRev 35 · syncRev 1793870000000 · buildDate 2026-11-05 · SW sdp-v0.0.6.d-s19.

Contents: repo_full_tree/ (69 files), patches/apply_release.cjs (SHA-256 lock), visual_proofs/ (16 shots D1–D8 across 360/390/1440 Light/Dark EN/SI), gates_terminal.txt (12/12 PASS 0 FAIL), sdp_v0.0.6.d_walkthrough.mp4 (24 fps).

Upgrades D1–D8 as specified; Iron Laws kept: 0 ElevenLabs credits (101 clips byte-identical), session.json 44,885 B SHA b1d178d3…, credits verbatim, strict ES5, 12/12 gates.
