#!/usr/bin/env node
/* v0.0.6.q — 390x844 visual proof captures for the release blueprint:
 * Stage 1 welcome, Stage 2 locked (Paragraph-1 gate), Stage 2 unlocked
 * (footer inside viewport), guide, player Word #1. */
'use strict';
const path = require('node:path');
const fs = require('node:fs');
const { chromium } = require('playwright-core');
const serverChromium = require('@sparticuz/chromium');
require('./chromium-env.cjs').ensureChromiumLibs();
const { start } = require('./static-server.cjs');

const ROOT = path.resolve(__dirname, '..');
const OUT = '/tmp/shots-v006q';
fs.mkdirSync(OUT, { recursive: true });

(async function main() {
  const server = await start({ root: ROOT });
  const browser = await chromium.launch({ executablePath: await serverChromium.executablePath(), args: [...serverChromium.args, '--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  await page.addInitScript(() => {
    window.__SDP_NO_LIVE__ = true;
    try { localStorage.setItem('sdp.settings', JSON.stringify({ appliedSettingsRev: 99, guideAutoPlay: false, mode: 'paper', lang: 'en', theme: 'light' })); } catch (e) {}
  });
  await page.goto(server.origin + '/index.html', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(900);
  /* 1 — Stage 1 welcome splash */
  await page.screenshot({ path: OUT + '/01-welcome-390x844.png' });
  /* 2 — Stage 2 locked: Paragraph 1 speaking, gate counting, buttons disabled */
  await page.evaluate(() => { document.getElementById('btnWelcomeContinue').click(); });
  await page.waitForTimeout(1400);
  const locked = await page.evaluate(() => ({
    cont: document.getElementById('btnBriefingContinue').textContent.trim(),
    contDisabled: document.getElementById('btnBriefingContinue').disabled,
    skipDisabled: document.getElementById('btnBriefingSkip').disabled,
    gateLeft: window.SDP.Views.briefingGateLeft(), beat1Done: window.SDP.Views.briefingBeat1Done(),
    contBottom: Math.round(document.getElementById('btnBriefingContinue').getBoundingClientRect().bottom),
    skipBottom: Math.round(document.getElementById('btnBriefingSkip').getBoundingClientRect().bottom), vh: window.innerHeight
  }));
  fs.writeFileSync(OUT + '/02-locked-state.json', JSON.stringify(locked, null, 1));
  await page.screenshot({ path: OUT + '/02-overview-locked-390x844.png' });
  /* 3 — unlocked: wait for the Paragraph-1 completion gate */
  await page.waitForFunction(() => document.getElementById('btnBriefingContinue') && document.getElementById('btnBriefingContinue').disabled === false, null, { timeout: 30000 });
  const unlocked = await page.evaluate(() => ({
    cont: document.getElementById('btnBriefingContinue').textContent.trim(),
    beat1Done: window.SDP.Views.briefingBeat1Done(), gateLeft: window.SDP.Views.briefingGateLeft(),
    contBottom: Math.round(document.getElementById('btnBriefingContinue').getBoundingClientRect().bottom),
    skipBottom: Math.round(document.getElementById('btnBriefingSkip').getBoundingClientRect().bottom), vh: window.innerHeight
  }));
  fs.writeFileSync(OUT + '/03-unlocked-state.json', JSON.stringify(unlocked, null, 1));
  await page.screenshot({ path: OUT + '/03-overview-unlocked-390x844.png' });
  /* 4 — the guide handover */
  await page.evaluate(() => { document.getElementById('btnBriefingContinue').click(); });
  await page.waitForTimeout(900);
  await page.screenshot({ path: OUT + '/04-guide-390x844.png' });
  /* 5 — player at Word #1 */
  await page.evaluate(() => { document.getElementById('btnGuideSkipStart').click(); });
  await page.waitForTimeout(1200);
  await page.screenshot({ path: OUT + '/05-player-word1-390x844.png' });
  await browser.close();
  await server.close();
  console.log('shots + states written to ' + OUT);
  console.log('locked:', JSON.stringify(locked));
  console.log('unlocked:', JSON.stringify(unlocked));
})().catch((e) => { console.error(e); process.exit(1); });
