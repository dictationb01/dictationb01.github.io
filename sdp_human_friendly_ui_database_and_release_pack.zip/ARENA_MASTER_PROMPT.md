# ARENA MASTER PROMPT — Smart Dictation Player v0.0.5.c "Sapphire Ladder" (Human-Friendly UI)

## 0. IRON LAWS
1. Zero ElevenLabs TTS credits. Never POST `/v1/text-to-speech/`. The 100-clip Alice pack (`data/elevenlabs-audio.json`) is read-only.
2. Byte locks stay untouched: `data/session.json` (55,260 B, SHA `1eaed80a290be4ef527b6a4c112cdb51419ea74c11f4e9ee37ad94bc7e79fef8`), `data/gas-source.txt` (13,764 B, SHA `591b9b086f6d3723afb2604a837ffc495c69a481c490f11e58131c2222b0981e`), both `assets/fonts/NotoSansSinhala-*.woff2`, `data.html` byte-equal to `data/index.html`, `SDP_ENC_V2` vault + `pinVerifier` in `data/config.json`.
3. Credits verbatim EN + SI everywhere: `Lecturer in Charge: Ms. Sumodya Sewmini · Creator: Hansana · Concept: Ayya01 (Lesandu)` and `නිර්මාණය: Hansana · අදහස: Ayya01 (Lesandu) · භාරකාර කථිකාචාර්ය: Ms. Sumodya Sewmini`.
4. All 12 gates green (`0 FAIL`), ES5 modules, 5-key localStorage law, every gate-required DOM id alive. No new build step, no new asset, no second stylesheet.

## 1. TOOL-CALL BUDGET (≤ 5 CALLS)
- TC1 unpack+clean (1 bash call)
- TC2 apply release (1 bash call)
- TC3 run gates (1 bash call)
- TC4 push+PR+merge (1 gh call, may be 2)
- Reserve 1 call for fixes only if a gate FAILs.

## 2. WHAT THIS RELEASE FIXES
- `assets/css/sdp-ui.css` rewritten in place: 97,804 → 57,942 B under the same 98,000 B gate cap. Six-step surface ladder per theme (canvas/sunken/card/elevated/interactive/accent-glass), 1px hairlines instead of card shadows, glass `blur(12px)` on header/rail/tabbar only, one accent-coloured action per screen, `pin-key` stays 56px, every ink/surface pair ≥ 4.5:1.
- Fixes 30 invisible word-list mark buttons (contrast 1.1 → 4.5+) and the Sinhala cockpit chip; Home gains a sapphire hero glow + semantic state pills; the cockpit beat ring becomes the single focal point with a 72px hero transport key; the word list gets a two-line card anatomy with a state-coloured left rail and circular Alice play button; the studio console gets calm header rhythm — all CSS-only, zero JS behaviour changes.
- Version literal bumped in lockstep (7 shipped surfaces + 11 test files + docs ledger): `0.0.4.c → 0.0.5.c`, `buildDate 2026-11-04`, `syncRev 1793740000001`, sw shell `sdp-v0.0.5.c-s15` with `PRESERVE_CACHES=[]` (keeps `sdp-youdao-v1`/`sdp-audio-clips` strings), manifest 3× `?v=0.0.5.c`.

## 3. EXECUTE (TC1–TC4)
### TC1 — unpack and clean
1. The user uploaded `sdp_human_friendly_ui_database_and_release_pack.zip` to the repo root.
2. Run: `unzip -oq sdp_human_friendly_ui_database_and_release_pack.zip -d /tmp/sdp_pack && (git rm -f '*.zip' 2>/dev/null || rm -f *.zip) && git status --short | head -20`
3. Never let any `.zip` or `.mp4` stay tracked in the working tree while gates run.

### TC2 — apply the release
1. Run: `node /tmp/sdp_pack/patches/apply_release.cjs "$PWD"`
2. It copies `repo_full_tree/` over the repo, then verifies in one pass: the 4 SHA-256 locks, the `data.html ≡ data/index.html` pair, `SESSION_BYTES` equals the live `session.json` size, `wOF2` magic on both fonts, and the `0.0.5.c` literal agreement across index.html / data.html / sw.js / manifest / version.json / config.json / data-meter.js / sdp-data-sync.js.
3. If you cannot run Node, copy instead: `cp -a /tmp/sdp_pack/repo_full_tree/. .` then verify `sha256sum data/session.json data/gas-source.txt assets/fonts/*.woff2` against §0.2.
4. Expect exit code 0 and the line `RELEASE APPLIED AND VERIFIED`.

### TC3 — run all 12 gates
1. Run: `npm run gates --prefix tests`
2. Acceptance: every line reads `G1..G12 — N PASS / 0 FAIL` and the command exits 0 (323 PASS records total).
3. If any gate FAILs: read its `FAIL` record, fix the named file, re-run this one command. Do not edit `tests/*.cjs` except to fix literal drift; never widen a gate.

### TC4 — ship on the pre-assigned branch
1. Run in order, replacing `$BRANCH` with Arena's current session branch — never create a new branch:
   - `BRANCH=$(git rev-parse --abbrev-ref HEAD)`
   - `git add -A && git commit -m "v0.0.5.c — Sapphire Ladder human-friendly UI (12/12 gates, 0 credits)"`
   - `git push origin "$BRANCH"`
   - `gh pr create --title "v0.0.5.c Sapphire Ladder" --body "12/12 gates, 0 FAIL. Credits: Ms. Sumodya Sewmini · Hansana · Ayya01 (Lesandu)."`
   - `gh pr merge "$BRANCH" --merge --delete-branch`
2. If `gh` asks anything, choose merge now.

## 4. ACCEPTANCE CHECKLIST
- [ ] `sha256sum data/session.json data/gas-source.txt assets/fonts/*.woff2` matches §0.2 exactly.
- [ ] `cmp data.html data/index.html` reports identical.
- [ ] `npm run gates --prefix tests` exits 0 with `0 FAIL` on all 12 gates.
- [ ] `grep -c "0.0.5.c" index.html data.html sw.js manifest.webmanifest data/version.json` each ≥ 2.
- [ ] No `.zip` or `.mp4` remains tracked: `git ls-files | grep -E "\.(zip|mp4)$"` is empty.
- [ ] Zero ElevenLabs spend: no POST to `/v1/text-to-speech/` anywhere in the diff.
- [ ] Credits lines verbatim in EN and SI on Home and About.
- [ ] PR merged to `main` in the same turn.
