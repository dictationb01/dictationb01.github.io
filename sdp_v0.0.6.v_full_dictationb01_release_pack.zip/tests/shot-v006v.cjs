
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright-core');
const serverChromium = require('@sparticuz/chromium');
require('./chromium-env.cjs').ensureChromiumLibs();
const { start } = require('./static-server.cjs');
const ROOT = path.resolve(__dirname, '..');
const OUT = '/home/z/my-project/work/shots';
(async () => {
  const server = await start({ root: ROOT });
  const executablePath = process.env.SDP_BROWSER_BIN || await serverChromium.executablePath();
  const args = serverChromium.args.filter((a) => !['--single-process','--disable-web-security','--allow-running-insecure-content','--disable-site-isolation-trials'].includes(a));
  const browser = await chromium.launch({ headless: true, executablePath, args });
  const viewports = [
    { tag: '320x568', w: 320, h: 568 },
    { tag: '360x640', w: 360, h: 640 },
    { tag: '375x667', w: 375, h: 667 },
    { tag: '390x844', w: 390, h: 844 },
    { tag: '768x1024', w: 768, h: 1024 },
    { tag: '1280x800', w: 1280, h: 800 }
  ];
  for (const vp of viewports) {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h }, hasTouch: true, isMobile: vp.w <= 768 });
    const page = await ctx.newPage();
    await page.goto(server.origin + '/index.html', { waitUntil: 'load', timeout: 45000 }).catch(() => {});
    await page.waitForTimeout(1800);
    await page.screenshot({ path: path.join(OUT, 'vp-' + vp.tag + '-welcome.png') });
    // open the briefing stage 2
    await page.evaluate(() => { const b = document.getElementById('btnWelcomeContinue'); if (b) b.click(); }).catch(() => {});
    await page.waitForTimeout(1400);
    await page.screenshot({ path: path.join(OUT, 'vp-' + vp.tag + '-briefing.png') });
    // the self-heal modal (T6 copy)
    await page.evaluate(() => { if (window.SDP && SDP.SelfHeal) SDP.SelfHeal.show('T6', { lastErr: 'QuotaExceededError' }); }).catch(() => {});
    await page.waitForTimeout(400);
    await page.screenshot({ path: path.join(OUT, 'vp-' + vp.tag + '-selfheal.png') });
    await ctx.close();
  }
  // Studio activity popup capture (desktop viewport, inject a demo ledger)
  const ctx2 = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page2 = await ctx2.newPage();
  await page2.goto(server.origin + '/index.html', { waitUntil: 'load', timeout: 45000 }).catch(() => {});
  await page2.waitForTimeout(1500);
  await page2.evaluate(() => {
    try {
      const s = JSON.parse(localStorage.getItem('sdp.settings') || '{}');
      s.telemetryLedger = { pulledAt: Date.now(), users: [
        { clientId: 'sdp_u_demo0123456789ab', sessions: [ { sessionNo: 1, startedAt: 1, endedAt: 2, dwellSec: 420, wordsCompleted: 26, score: 87, missedWords: ['harbour','canal'], lagMs: 40, device: { class: 'phone', net: '3g' } } ], incidents: [ { type: 'selfheal_T2', viewport: '390x844', net: '3g' } ] }
      ] };
      localStorage.setItem('sdp.settings', JSON.stringify(s));
    } catch (e) {}
  }).catch(() => {});
  await page2.reload({ waitUntil: 'load' }).catch(() => {});
  await page2.waitForTimeout(1500);
  await page2.evaluate(() => {
    try { if (window.SDP && SDP.Studio && SDP.Studio.openStudioActivityPopup) SDP.Studio.openStudioActivityPopup(); } catch (e) {}
  }).catch(() => {});
  await page2.waitForTimeout(900);
  await page2.screenshot({ path: path.join(OUT, 'studioActivityPopup-1280x800.png') });
  await ctx2.close();
  await browser.close();
  server.close();
  console.log('SHOTS DONE');
})().catch((e) => { console.error(e); process.exit(1); });
