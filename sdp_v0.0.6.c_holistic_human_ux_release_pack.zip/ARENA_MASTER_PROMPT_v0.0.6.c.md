# Arena Master Prompt — Smart Dictation Player v0.0.6.c Holistic Human-UX Release Merge

You are the Arena release agent for `dictationb1/dictationb1.github.io`. This pack ships the v0.0.6.c Holistic Human-UX release: the five Creator-reported ergonomic failures (F1–F5) fixed and re-verified with all 12 automated gates green (0 FAIL) and 39 Playwright proof checks green.

**Stamp (lockstep):** `appVersion/version '0.0.6.c'` · `ver 18` · `schema 18` · `settingsRev 34` · `syncRev 1793860000000` · `SW_VERSION 'sdp-v0.0.6.c-s18'` / `SHELL_CACHE 'sdp-v0.0.6.c-s18-shell'` · `TARGET='0.0.6.c'` · `buildDate 2026-11-05`.

## What shipped (F1–F5)

- **F1 Studio word-delta broadcast** — `detectWordDeltas()` compares the live edit surface against the committed `SDP.Sync.words()` baseline on every input/change; even at 30/30 one modified spelling flips `ST.wordsDirty`, the recognition pill reads `30 / 30 Words Recognized ✓ ⚠️ 1 Word(s) Modified ("curious") — click Broadcast to Auto-Enrich & Sync`, and the replaced word's stale enrich fields are cleared. Both `#lecturerSyncBar` / `#btnSyncClassSettings` and `#studioSecurityBar` / `#btnPublishWordsAndVoice` gain the pulsing `data-dirty` RED action state (`#E11D48`); a landed publish clears it to emerald `data-synced` and stamps `Rev #…` on `#lecturerSyncLast`. The broadcast button now runs the unified pipeline when words changed — fast delta enrich (only modified words, via the saved vault keys), delta voice under the 0-credit sha1 guard, atomic 4-file publish `session.json → config.json → elevenlabs-audio.json → version.json` — while a pacing-only change keeps the exact config+version sequence (G8.6c green). Tab-exit with dirty edits raises the 3-tap 🔴 Publish-Sync-&-Leave / 🔒 Discard-Lock-&-Leave / ✏️ Stay modal (EN + SI); clean exits still auto-lock instantly.
- **F2 Cockpit fold** — the duplicate 1–30 grids are gone: `#boardJumper` lives inside a closed `<details>` drawer (48px `#boardJumperToggle`) and `#sessionPills` stays in its own drawer; the cockpit card is first, the countdown clock ring (`#beatRing` + overlaid `#beatSeconds`) is the hero, and the transport deck (⏯ `#btnPlayPause`) is docked directly beneath — ring + Play/Pause + Show-Current-Word all above the 360×640 fold (verified `rect.bottom ≤ 600`, zero scrolling). Every contract id, aria-label and ≥48px target preserved (G3.10 / G5.6 / G5.7g / G7.3 green).
- **F3 Two-mode themes** — human-facing theme UI is exactly ☀️ Light Mode (Default) + 🌙 Dark Mode; `#btnTheme` toggles light↔dark only; `<option value="board" hidden>` and `html[data-theme='board']` stay machine-reachable for gates.
- **F4 Scroll-proof sliders** — `.stepper input[type='range']` is `pointer-events:none`; a Playwright touch-drag straight across `#setWriteSecs` leaves Writing Time at 5s while the 48px −/+ steppers move it cleanly and programmatic dispatch still works.
- **F5 Visual maturity** — dual-tone inner top-highlights, consistent 12/16px radii, premium practice cards (single-slash `/ɪmˈpɔːtənt/` IPA, hover-lift flashcard, crisp quiz tiles with ok/bad halos), lifted icon medallions, quieter cockpit hierarchy, header contrast in both modes.

Zero ElevenLabs credits were spent; `data/session.json`, `data/gas-source.txt`, both Sinhala fonts and all 100 Alice clips are byte-identical.

## Merge procedure

Work in your local clone of `dictationb1/dictationb1.github.io` on a fresh branch off `main`.

### TC1 — prepare the release tree

```bash
BRANCH="release/v0.0.6.c"
git fetch origin main
git checkout -b "$BRANCH" origin/main
for z in *.zip; do [ -e "$z" ] || continue; unzip -o -q "$z" -d /tmp/sdp_pack; done
git rm -f '*.zip' 2>/dev/null || true
rm -f *.zip
```

If the repo already carries zips at the root, the loop unpacks each to `/tmp/sdp_pack` (the pack nests `patches/`, `repo_full_tree/` and the master prompt at its root) and then removes the zips from both git and disk so the release tree stays clean.

### TC2 — install the 49 locked files

```bash
node /tmp/sdp_pack/patches/apply_release.cjs "$PWD"
```

Expected output: `apply_release: 49 files installed, 0 failures`. The installer verifies a SHA-256 lock for every file before writing it; any mismatch or missing file fails loudly instead of installing.

### TC3 — run the release gates

```bash
npm install --prefix tests --no-audit --no-fund
npm run gates --prefix tests
```

Expected: all 12 gates green, `0 FAIL` — G1 check 110 PASS · G2 upgrade 12 · G3 phase1 102 · G4 server 68 · G5 browser 60 · G6 upgrade-browser 15 · G7 e2e 52 · G8 live-lab 39 · G9 audit-v42 47 · G10 voice-guide 38 · G11 vault-sync 74 · G12 studio-safety 94. If any gate fails, stop and report the failing check — do not merge a red tree.

### TC4 — publish the release

```bash
BRANCH=$(git rev-parse --abbrev-ref HEAD)
git add -A
git commit -m "v0.0.6.c — Holistic Human-UX release (F1–F5): studio word-delta broadcast, cockpit clock-ring fold, two-mode themes, scroll-proof sliders, visual maturity" || true
git push -u origin "$BRANCH"
gh pr create --base main --head "$BRANCH" --title "v0.0.6.c Holistic Human-UX release" --body "F1-F5 fixed; 12/12 gates, 0 FAIL; ver 18 / settingsRev 34 / syncRev 1793860000000."
gh pr merge "$BRANCH" --merge --delete-branch
```

After the merge, GitHub Pages serves the release; classroom devices pick it up on their next `checkForUpdates` cycle (settingsRev 34 > 33 broadcast).

## Release ledger

| Field | Value |
| --- | --- |
| appVersion / version | 0.0.6.c |
| ver / schema | 18 / 18 |
| settingsRev | 34 |
| syncRev | 1793860000000 |
| SW_VERSION / SHELL_CACHE | sdp-v0.0.6.c-s18 / sdp-v0.0.6.c-s18-shell |
| buildDate | 2026-11-05 |
| Gates | 12/12 PASS, 0 FAIL |
| Proof checks | 39/39 PASS (Playwright) |
| Preserved byte-identical | session.json, gas-source.txt, both .woff2 fonts, 100 Alice clips |
