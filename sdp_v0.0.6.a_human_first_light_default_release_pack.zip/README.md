# sdp_v0.0.6.a — Human-First Daylight release pack

Smart Dictation Player for the CCBE Galle Branch — B1 English Class (Sri Lanka).
Version stamp: `0.0.6.a` · `ver 16` · `schema 16` · `settingsRev 31` · `syncRev 1793750000000` · `buildDate 2026-11-04`.

## What this pack delivers

1. **Light Mode is the mandatory default theme** on every surface (index.html, data.html pair, DEFAULT_SETTINGS, config.json classSettings, PWA manifest `#F8FAFC`), with dark and Smart Board kept as fully functional optional themes. Light contrast hardening: `--accent-fg` foreground tokens on glass surfaces, 1.5px `#CBD5E1` input borders on `#F1F5F9`, crisp 1px `#E2E8F0` card edges.
2. **Real British Phonemic IPA** — all 60 words in `data/session.json` (30 Session 8 + 30 archived Session 7) now carry Oxford/Cambridge IPA (important → `/ɪmˈpɔːtənt/`), real POS, B1 English definitions, accurate Sinhala meanings and natural B1 example sentences. `data/session.json` re-pinned at exactly **44,885 B**, SHA-256 **`b1d178d3…`** across `tests/check.cjs`, `tests/audit-v42.cjs`, `.github/workflows/checks.yml`, `data.html`, `data/index.html`, `docs/ARCHITECTURE_MAP.md`, `docs/CHANGELOG_LEDGER.md`.
3. **Mobile word reveal** — `#boardClassBar` is a first-class cockpit control on every viewport (phones included); every beat re-arms the hidden state, so the spelling never leaks during a beat (R10 / G7.3c preserved).
4. **Human dictation clock** — a new `#beatPhasePill` (EN + SI): 🎧 Listening · Repeat 1/2 → ✍️ Write the word · 5s → ⏳ Finish writing · 3s (pulsing amber), with smooth 0.12s ring/bar transitions. Gate-verbatim state lines, ring colours and countdown assertions untouched.
5. **All-in-One lecturer wizard** — live `N / 30 Words Recognized ✓` pill on a 400ms paste debounce, spring-pulsed Master CTA, and a 4-step animated pipeline (verify vault & keys → auto-enrich with real IPA → Alice voice pack sync under the 0-credit guard → atomic publish + broadcast), plus a bilingual Problem + Solution + 1-Click Fix error card.
6. **Studio offline IPA engine** — 60-word `BRITISH_IPA_LEXICON` + deterministic British G2P transcriber; `fallbackEnrich()` can never print `/word/` placeholders again; `mergeEnrichRecord()` strips them from payloads.

## Contents

| Path | Purpose |
|---|---|
| `01_forensic_ux_and_light_mode_audit/FORENSIC_UX_AUDIT.md` | 18-defect BEFORE→AFTER register, screen-by-screen notes, iron-law invariants |
| `02_visual_proofs/screenshots/` | 104 PNGs — 52 BEFORE (pristine `af1e6cb` worktree) + 52 AFTER, 4 viewports × 3 themes × 2 languages |
| `02_visual_proofs/sdp_v0.0.6.a_walkthrough.mp4` | 24 fps, 720×1280, 5.25 s walkthrough |
| `02_visual_proofs/gates_terminal.txt` | Verbatim `npm run gates --prefix tests` log — 12/12 PASS, 0 FAIL (585 assertions) |
| `02_visual_proofs/dom_state_proofs.json` | 18/18 live DOM assertions (light boot, mobile reveal, IPA, phase pill, studio wizard) |
| `repo_full_tree/` | The complete upgraded repository (no `.git`, no `node_modules`) |
| `patches/apply_release.cjs` | Deterministic single-command installer with a 48-file SHA-256 lock table |

## Apply it

From the repository root:

```bash
rm -rf /tmp/sdp_pack && mkdir -p /tmp/sdp_pack
unzip -o sdp_v0.0.6.a_human_first_light_default_release_pack.zip -d /tmp/sdp_pack
git rm -f --cached '*.zip' 2>/dev/null || true
node /tmp/sdp_pack/patches/apply_release.cjs "$PWD"
npm install --prefix tests 2>/dev/null || true
npm run gates --prefix tests   # expect 12/12 PASS, 0 FAIL
```

## Iron laws honoured

Zero ElevenLabs credits (no POST to `/v1/text-to-speech` anywhere; all 100 Alice clips `Xb7hH8MSUJpSbSDYk0k2` / `eleven_flash_v2_5` byte-preserved; the voice step runs `force:false`). `data/gas-source.txt` (13,764 B) and both Sinhala woff2 fonts untouched. `data.html` == `data/index.html`. Five-key localStorage law intact. Every shipped `.js` parses as ES5 (max line ≤ 400, avg ≤ 200).

## Credits (verbatim, EN + SI)

Lecturer in Charge: Ms. Sumodya Sewmini · Creator: Hansana · Concept: Ayya01 (Lesandu)
නිර්මාණය: Hansana · අදහස: Ayya01 (Lesandu) · භාරකාර කථිකාචාර්ය: Ms. Sumodya Sewmini
