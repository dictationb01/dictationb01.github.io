#!/usr/bin/env node
'use strict';
/* Smart Dictation Player v0.0.6.c (Holistic Human-UX release) — deterministic installer.
 * Usage: node apply_release.cjs <repo-root>
 * Unpack the release zip to /tmp/sdp_pack first (see ARENA TC2). */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const PACK = __dirname;
const ROOT = process.argv[2] || process.cwd();
const FILES = [".github/workflows/checks.yml", ".github/workflows/pages.yml", ".gitignore", "README.md", "assets/css/sdp-ui.css", "assets/fonts/NotoSansSinhala-Bold.woff2", "assets/fonts/NotoSansSinhala-Regular.woff2", "data.html", "data/config.json", "data/data-meter.js", "data/elevenlabs-audio.json", "data/gas-source.txt", "data/index.html", "data/sdp-audio-speech.js", "data/sdp-data-sync.js", "data/sdp-dictation-engine.js", "data/sdp-morphe-hooks.js", "data/sdp-ui-views.js", "data/session.json", "data/studio.js", "data/version.json", "docs/ARCHITECTURE_MAP.md", "docs/CHANGELOG_LEDGER.md", "docs/DAILY_UPGRADE_PROMPT_TEMPLATE.md", "docs/SYNC_AND_DATA_CONTRACT.md", "docs/UI_COMPONENT_GUIDE.md", "index.html", "manifest.webmanifest", "sw.js", "tests/README.md", "tests/app-harness.cjs", "tests/audit-v42.cjs", "tests/browser.cjs", "tests/check.cjs", "tests/chromium-env.cjs", "tests/e2e.cjs", "tests/fixtures/paste-30.txt", "tests/live-lab.cjs", "tests/package-lock.json", "tests/package.json", "tests/phase1.cjs", "tests/server.cjs", "tests/static-server.cjs", "tests/studio-safety.cjs", "tests/test-pin.cjs", "tests/upgrade-browser.cjs", "tests/upgrade.test.cjs", "tests/vault-sync.cjs", "tests/voice-guide.cjs"];
const LOCKS = {
  ".github/workflows/checks.yml": "26bd918faec3324d8a309c3b06b61e51544ad39c8175ced615991a87a4e38b85",
  ".github/workflows/pages.yml": "c8e49d422b5f58e17ca2bd208f9cd35ec1ab2c686ff42a9f2332185e262c44b6",
  ".gitignore": "bc0561efe821162c376d0fa03788e16f45e02c009fbd91742b7ff64df0dc5322",
  "README.md": "4e4a0639f8d42e36a7bb14712bb1ae21650341a78c30a33a0e69c909be4e5be4",
  "assets/css/sdp-ui.css": "93ae3628bd7c80edf9c8e3186a7ba89cd2647aade97775dac8b7f4e8d3bd2472",
  "assets/fonts/NotoSansSinhala-Bold.woff2": "bf59c1487b0a88a07a678190fd7a6e93aa01c5ec3f3f2f9e349922ac944a643e",
  "assets/fonts/NotoSansSinhala-Regular.woff2": "23f1503e1e75413903dff05f4415f59d4b903cfeb2a8d1c0047ac158d20ff280",
  "data.html": "a8b586e1c33d513ef99280347440c1ab436cd7c8fcec9e18199eeb297cc1e72f",
  "data/config.json": "64903698aa688a77a0cae7650a3526e0cb1705816dfab262fc592989985d8b24",
  "data/data-meter.js": "eb9283320df6d97624dc6a5c6fa890d08dede85a2f9c4f2df7758d9eb501862f",
  "data/elevenlabs-audio.json": "1679c2ac96e3d998f8f42cddcb06b80d5e758e873f17fdd0711a7fa8621fe1c1",
  "data/gas-source.txt": "591b9b086f6d3723afb2604a837ffc495c69a481c490f11e58131c2222b0981e",
  "data/index.html": "a8b586e1c33d513ef99280347440c1ab436cd7c8fcec9e18199eeb297cc1e72f",
  "data/sdp-audio-speech.js": "0a9570fe357343c5e8a3b3e751c6a67cc73b6505654d03f65f2873adae3e1285",
  "data/sdp-data-sync.js": "429ef022c542c1921c3c62f0fb9ec193aa0e8dfdfef8cdad4d82a765265d4846",
  "data/sdp-dictation-engine.js": "ffe95723aa1a3968b17f277a561fb0ca62ea67875b72b0fbb6a695ba58910413",
  "data/sdp-morphe-hooks.js": "460cd3a7ddac3730b52ccc1d60005abc8ffb6238f1f29dcb2c8d700572fe03d1",
  "data/sdp-ui-views.js": "f7db6d533de82a652949c1ea2971cf5ccdc992352f6c3ca8b4f0b680684abbc0",
  "data/session.json": "b1d178d39f705d1e2d3e3e5e371b83dc68ac577bf2375ec22eb66a82dc1d175e",
  "data/studio.js": "ddffb5ce9b59081a6ba9acbf8d0b6fb47f1e4f08f7c94811539ece5a83913385",
  "data/version.json": "68ef5969be7ae6813b1ce3809d2204bca1dfbe708c7bc1768136072e1363cdea",
  "docs/ARCHITECTURE_MAP.md": "fe9bc6e9abc4ed204b7d71575cad643402e42b3fa2a25df3381366dfaaec5f93",
  "docs/CHANGELOG_LEDGER.md": "92e67c3c07367e97ecd41998490a79608fc338ce245776521d866798c1b692d0",
  "docs/DAILY_UPGRADE_PROMPT_TEMPLATE.md": "6840f532c4d2f1bb5cd862321c33ecf97a93ed910015215954f8a6384380aaa6",
  "docs/SYNC_AND_DATA_CONTRACT.md": "96673c648a02bec074b949226879de8ed61e78a19a9f5d210ab88f96262f3bf7",
  "docs/UI_COMPONENT_GUIDE.md": "cd693e3eaa3b46bcf8dbc13c7f14db2f9a4e9222731de7005c8ce2daec36ead5",
  "index.html": "065690028db57d74a66f6c8df498d9caa5804c6039d04fdb78aacb6297f3f223",
  "manifest.webmanifest": "cfee485bc2ce63ccf5ff7dbf425ae8fb05f3689ba53cde6e6e2954c2d7f7eb4b",
  "sw.js": "0d8a80985a1214d2e52382dece0fb447596187953c9d03c8f2ec049dac7553a8",
  "tests/README.md": "dc3046ffba6fb815f103bdee877bd9dd926daff26d935a7535b685da5d3b2164",
  "tests/app-harness.cjs": "65a3933075fd68f5ead70bbab63522a620e3d92aaf43d51173f72e5b3cf4b975",
  "tests/audit-v42.cjs": "da83d9cdde63f5a848b8e77a9b638635cf53e277dd136b19bb366ea18c9cc964",
  "tests/browser.cjs": "d0783e04f8ff43c487c1116b9af74d5a02f3cc29660aae3d15f1167be513fff6",
  "tests/check.cjs": "9d62af3d093c80197ddf2a79ecd7d9dd2971154d67b934f38a2c3b274185f92b",
  "tests/chromium-env.cjs": "15232c3dd3de9b40161cffed70b7777dd86723b547cac88b8020ba857f16990b",
  "tests/e2e.cjs": "f5adddadc78bbf6ce5b60dc776079c346c5c2944807cd0bc23277fed3fd50795",
  "tests/fixtures/paste-30.txt": "ef49fda885b392f86530072d9604c5d6a368c0a902c9cc1a36040d5d49120447",
  "tests/live-lab.cjs": "8eab3a07d48c345e35fb62bc6329627b70fc539ec62e4f9e168cf0abae86a1bf",
  "tests/package-lock.json": "eb3ebf8b9bc6ac0d26f45644e82a90d905c0067c525cd5daf882f8341fe7c499",
  "tests/package.json": "bfda32a417dc7f52f373b8f6a84bdb0c17aedbd894f71f72a39cf360e57198ad",
  "tests/phase1.cjs": "dcbcc3ce33f5fc26b7002fa5e50cea007ffb052dfccc84740fa498992f819cca",
  "tests/server.cjs": "03633dacf214d6a0aa8e452327a75c18d70d25e578bdc734d4b52b227e05cfab",
  "tests/static-server.cjs": "517dff432c0e13d39cc970200d667520ceff3ab27e5c69671faaa32e69594e06",
  "tests/studio-safety.cjs": "dfd5d6a4c523a53648e1686e188f86c9f54536fbf93e17af38ba8f5a037f661d",
  "tests/test-pin.cjs": "d82ade1d2bf15f133698608617658feeeeaac83d4bc03e25f0385e1491c79e49",
  "tests/upgrade-browser.cjs": "55b5e2c6a4289eff355aa6ae6e95f2a6472dc99d9cfc940012f81d5b565cab87",
  "tests/upgrade.test.cjs": "a897ec600450d1e18bdad329ae386a56b98159603b8d72cb1efe2ed16be60235",
  "tests/vault-sync.cjs": "54f751611f5e087f8e374d819120bd5e3b242ffdad58fe5de2deb457d0897f3a",
  "tests/voice-guide.cjs": "1ffa674ea84ff4bad8be467cbd57505ff98a88b91bb607c5de61ef89b83e833d"
};
let fail = 0;
for (const rel of FILES) {
  const src = path.join(PACK, '..', 'repo_full_tree', rel);
  let buf;
  try { buf = fs.readFileSync(src); } catch (e) { console.log('MISSING ' + rel); fail++; continue; }
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  if (sha !== LOCKS[rel]) { console.log('SHA MISMATCH ' + rel); fail++; continue; }
  const dest = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, buf);
}
console.log(fail === 0 ? 'apply_release: ' + FILES.length + ' files installed, 0 failures' : 'apply_release: ' + fail + ' failures');
process.exit(fail ? 1 : 0);
