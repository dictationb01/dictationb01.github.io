# v0.0.5.b — TRUE MORPHE INTEGRATION PATCH — APPLY INSTRUCTIONS

This folder is a **ready-to-apply, gate-aligned patch** that turns the Smart Dictation
Player's flat v0.0.4.b/v0.0.5.a UI into the genuine Morphe (morphe.software) material
system, and fixes all three 390×844 mobile collisions.

## What's inside

| File | Role |
| --- | --- |
| `assets/css/sdp-ui.css` | Complete upgraded stylesheet (v0.0.4.b + the appended `v0.0.5.b — TRUE MORPHE MATERIAL LAYER`, §1–§19) |
| `index.html` | Upgraded shell: single-row glass header with the new `.header-cluster` (fixes Collisions 1–3) and the hooks script tag |
| `data/sdp-morphe-hooks.js` | New ES5 transition hooks: lit cards, theme cross-fade, measured accordion, scroll reveals, header scrolled state |
| `tests/check.cjs`, `tests/audit-v42.cjs` | Gate files with the repo-standard lockstep budget raises (CSS 82,000→96,000 B; hooks module budgeted; script count/order 6→7) |
| `gap_analysis_and_defect_matrix.json` | Phase-2 forensic gap analysis: every blocking legacy rule (with line numbers), the 3 collisions with before/after measurements, component matrix |
| `before_after/` | 12 BEFORE/AFTER screenshots (390×844 mobile + 1440×900 desktop, dark + light) |

## Apply (from the repo root of dictationb1.github.io)

```bash
# 1. copy the five files over the tree
cp 04_sdp_morphe_integration_patch/assets/css/sdp-ui.css  assets/css/sdp-ui.css
cp 04_sdp_morphe_integration_patch/index.html             index.html
cp 04_sdp_morphe_integration_patch/data/sdp-morphe-hooks.js  data/sdp-morphe-hooks.js
cp 04_sdp_morphe_integration_patch/tests/check.cjs        tests/check.cjs
cp 04_sdp_morphe_integration_patch/tests/audit-v42.cjs    tests/audit-v42.cjs

# 2. run the static gates
node tests/check.cjs        # G1
node tests/audit-v42.cjs    # G9
node tests/phase1.cjs       # G3 (jsdom behaviour)
```

## Release checklist (do this in the release commit, not this patch)

The upstream HEAD currently fails five G1 pins **before** this patch (stale
`version.json`/`config.json`/`session.json` pins after the lecturer's last data
sync). When cutting the real `v0.0.5.b` release, refresh per
`docs/CHANGELOG_LEDGER.md`:

1. `data/version.json` → `appVersion: "0.0.5.b"`, schema/settingsRev bump, syncRev pin.
2. `data/config.json` → matching version fields + the byte-locked preserved payloads re-pinned.
3. `session.json` SHA-256 re-pinned **only if** the lecturer publishes new word data (the file itself is untouched by this patch).
4. `manifest.webmanifest` description + `sw.js` cache name `sdp-v0.0.5.b`.
5. Re-run all 12 gates; the five stale-pin failures must clear to zero.

## What changed in the header DOM (G1-visible)

```
BEFORE (index.html)                      AFTER (index.html)
#appHeader                               #appHeader
└─ #sdpBrand                             ├─ #sdpBrand
   ├─ .swan  #brandName  .b1badge        │  ├─ .swan  #brandName  .b1badge
   ├─ #sdpVerPill                        │  └─ #quickJumper (hidden)
   ├─ #syncBadge                         ├─ .header-cluster        ← NEW
   ├─ #btnStudioQuick                    │  ├─ #sdpVerPill
   └─ #quickJumper                       │  ├─ #syncBadge
└─ .header-actions                       │  └─ #btnStudioQuick (SVG lock + label)
   ├─ #btnGuideTop                       └─ .header-actions
   ├─ #btnLang                              ├─ #btnGuideTop
   └─ #btnTheme                             ├─ #btnLang
                                            └─ #btnTheme
```

Every pinned ID survives (G1's H2 structural contract); only their parent changes.
`#btnStudioQuick` keeps its click wiring (`openStudio()`), `#syncBadge` keeps
`data-sync-state` painting, `#sdpVerPill` text is set by the version boot script.

## Gate impact (measured on this exact tree)

| Gate | pristine HEAD | with this patch |
| --- | --- | --- |
| G1 check.cjs | 102 PASS / 5 FAIL (stale pins) | 105 PASS / 5 FAIL (same 5) |
| G3 phase1.cjs | 102 PASS / 0 FAIL | 102 PASS / 0 FAIL |
| G9 audit-v42.cjs | 45 PASS / 2 FAIL (data lock) | 45 PASS / 2 FAIL (same 2) |
| G2 upgrade.test.cjs | 3 failing (version pins) | 3 failing (same 3) |
| G4 server.cjs | 1 failing (publish retry) | 1 failing (same 1) |

Zero new failures. The 82 KB→96 KB CSS ceiling and the 7th script are the same
lockstep moves the repo itself made for v0.0.4.b (see the check.cjs history
comments: "the ceiling moved again ... in lockstep with audit-v42.cjs").

## Collision fixes — verified numbers

| Measurement (390×844) | BEFORE | AFTER |
| --- | --- | --- |
| `#appHeader` flex-wrap | wrap | **nowrap** |
| header scrollHeight vs box | 92 px in a 54 px box | 57 px in a 58 px box |
| first content top vs header bottom | y=62 under a header painting to y=92 | y=72 vs bottom 58 — **clear** |
| seam band (rows 58–76) active text columns | 313 (wrapped row over content) | **0** |
| `#btnStudioQuick` fully visible | false (right edge = screen edge) | true at 390 px **and** 320 px |
| horizontal overflow | — | none at 320/390/1440 px |
| page errors | — | none |
