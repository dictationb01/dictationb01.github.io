# Morphe Official UI Materials Database & Patch — README

**Target site:** https://morphe.software/ (source: https://github.com/MorpheApp/morphe-website, commit `0ee51c8`, 2026-11-01)
**Extracted:** 2026-11-03, Playwright Chromium 1.57 + curl, dark & light themes × 1440×900 / 768×1024 / 390×844.

## Folder map

```
01_morphe_raw_sources/          Verbatim downloads from https://morphe.software/
  index.html                    Home page (39,457 B as served)
  kit/kit.css                   THE UI kit — tokens, navbar, buttons, motion (26,445 B as served)
  css/styles.css                Page component styles (55,289 B as served)
  kit/kit.js, js/i18n.js, js/testimonials.js, js/changelog.js, js/donate.js
  routes/                       changelog, donate, faq, microg, translate (raw HTML)
  images/                       morphe_wordmark_dark/light.svg, crowdin.svg, crowdin-small.svg
  fonts/                        Google Fonts CSS declarations actually linked by the site
  favicon*, site.webmanifest, apple-touch-icon.png
  (unminified source of every file: github.com/MorpheApp/morphe-website — cloned alongside this archive's build)

02_morphe_extracted_database/
  morphe_design_tokens.json         50 colour tokens (light+dark values), 10 gradients, 6 shadow
                                    recipes, radius/spacing ladders, typography scale, layout math,
                                    12 breakpoints, viewport measurements, contrast ratios
  morphe_animations_and_transitions.json   All 13 @keyframes verbatim, 52 transition rules,
                                    26 micro-interactions, JS animation hooks, reduced-motion policy
  morphe_components_catalog.css     Isolated reusable material classes (m-* prefix) with the token block
  morphe_live_computed_all_combos.json     Raw computed-style dump, 6 viewport×theme combos
  morphe_cssom_dump.json            Raw CSSOM dump (keyframes/transitions/media queries/gradients)

03_morphe_live_screenshots/      17 high-res captures (2× DPR):
  morphe_dark_desktop_1440x900_full.png     full page, dark
  morphe_light_desktop_1440x900_full.png    full page, light
  morphe_dark_tablet_768x1024_full.png
  morphe_light_mobile_390x844_full.png
  morphe_dark_mobile_390x844_drawer_open.png
  closeup_navbar_dark.png / closeup_hero_buttons_dark.png (hover) / closeup_pill_tabs_dark.png (hover)
  closeup_feature_card_dark.png (hover) / closeup_community_card_dark.png (hover)
  closeup_testimonial_card_dark.png (hover) / closeup_footer_dark.png
  closeup_faq_item_open_dark.png + closeup_faq_item_open_hover_lit_dark.png (lit border glow)
  closeup_donate_tier_hover_light.png / closeup_donate_hero_card_light.png
  closeup_kit_search_focus_light.png (focus ring glow)
  sdp_before_* / sdp_after_*                    Smart Dictation Player proof shots (see 04)

04_sdp_morphe_integration_patch/   Ready-to-apply v0.0.5.b patch for
                                  https://github.com/dictationb1/dictationb1.github.io
  APPLY_v0.0.5.b.md                Step-by-step apply + release checklist + gate impact table
  assets/css/sdp-ui.css            Complete upgraded stylesheet (v0.0.4.b + Morphe material layer §1–§19)
  index.html                       Single-row glass header with .header-cluster (fixes 3 collisions)
  data/sdp-morphe-hooks.js         ES5 transition hooks (lit/theme/accordion/reveal/scroll)
  tests/check.cjs, tests/audit-v42.cjs   Lockstep gate-budget alignment
  gap_analysis_and_defect_matrix.json    Every blocking legacy rule + collision measurements
  before_after/                    12 BEFORE/AFTER screenshots (mobile + desktop, dark + light)
```

## Key findings (one screen)

- Morphe's motion identity: `--spring: cubic-bezier(0.34, 1.4, 0.64, 1)` upgraded to
  `linear(0, 0.06 3%, 0.25 7.5%, 0.62 15%, 0.87 23%, 1.01 32%, 1.04 39%, 1.025 48%, 1.003 62%, 1)`
  via `@supports`, plus `--ease-emph: cubic-bezier(0.2, 0, 0, 1)`.
- Glass is a core material: navbar + mobile drawer `backdrop-filter: blur(12px)` over
  `--bg-glass: rgba(24,24,27,.8)` (dark) / `rgba(255,255,255,.8)` (light).
- Surfaces: zinc neutrals (`#18181B` page, `#1F1F23` card, `#303036` border in dark),
  1px borders everywhere, two-layer shadows, radius ladder 8/10/14/16/22.
- The SDP legacy `backdrop-filter: none !important` kill-switch (sdp-ui.css:168–171) is
  the single reason v0.0.5.a still looked like v0.0.4.b; it is removed by the patch.
