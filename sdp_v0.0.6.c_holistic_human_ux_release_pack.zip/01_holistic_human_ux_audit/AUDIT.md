# SDP v0.0.6.c — Holistic Human-UX Audit

## Part 1 — The five Creator-reported failures and their verified fixes

| # | Failure (v0.0.6.b) | Root cause | Fix shipped in v0.0.6.c | Verified proof |
|---|---|---|---|---|
| F1 | Changing one word + clicking "Broadcast Current Pacing & Settings" ignored the word change; no red warning; stale enrich; awkward tab guard | #btnSyncClassSettings only called publishConfigAndVersion(); the recognition pill counted words without comparing content; the guard blocked clean exits | detectWordDeltas() per-word baseline compare; ST.wordsDirty; RED pulsing data-dirty state on both bars; unified delta enrich + 0-credit delta voice + atomic 4-file publish on the broadcast button; 3-tap Unsaved-Changes guard modal (EN/SI) that never traps a clean exit | T-C1..T-C9: clean=no dirty, 1-word edit lights all four nodes red, pill reads "30/30 ✓ ⚠️ 1 Word(s) Modified ("curious")", publish lands session→config→audio→version, red clears to emerald + Rev stamp; guard modal shown + Discard&Leave switches instantly |
| F2 | Two duplicate 1–30 jumper grids pushed the clock and Play/Pause below the fold | #sessionProgressStrip pills + #boardJumper grid both rendered openly above the cockpit card | single closed <details> drawer; cockpit card first; clock-ring hero with overlaid seconds; transport deck docked beneath the ring | C-A1..C-A9: ring bottom ≤ 600px, Play/Pause bottom ≤ 600px, zero expanded 1–30 grids, drawer opens to exactly 30 chips |
| F3 | Three user-facing theme modes (Light/Dark/Smart Board) confused users | toggleTheme cycled light→board→dark; #setTheme offered three visible options | two-mode UI: ☀️ Light (default) + 🌙 Dark; board option hidden but machine-reachable for gates | H-D1..H-D5: toggle cycles light↔dark only; canvases rgb(248,250,252)/rgb(15,20,32); 2 visible options + hidden board |
| F4 | Vertical scroll on a phone snapped sliders (Writing Time 5s→15s) | touch-action:pan-y alone still lets pointerdown on the track snap the value | pointer-events:none on the range track; values move via 48px steppers, presets or programmatic dispatch only | S-B1..S-B6: touch-drag across #setWriteSecs keeps 5s; +/− steppers move to 6s/4s; dispatch sets 8s |
| F5 | UI still looked amateurish; flat pills, mismatched symbols | no unified surface craft | dual-tone inner top-highlights, 12/16px radii, premium practice cards (single-slash IPA), crisp quiz tiles, balanced header both modes | G5-G8 proof captures: practice /ɪmˈpɔːtənt/ single-slash, 30-word deck, home light/dark/SI |

## Part 2 — Regression safety

- All 12 automated gates re-pinned in lockstep and green with 0 FAIL (G1 110 · G2 12 · G3 102 · G4 68 · G5 60 · G6 15 · G7 52 · G8 39 · G9 47 · G10 38 · G11 74 · G12 94).
- 39 Playwright verification checks PASS (verification.json embedded below).
- Zero ElevenLabs credits: data/session.json, data/gas-source.txt, both Sinhala fonts and all 100 Alice clips byte-identical.
- Version lockstep across all seven surfaces: 0.0.6.c / ver 18 / settingsRev 34 / syncRev 1793860000000 / buildDate 2026-11-05 / SW sdp-v0.0.6.c-s18.

## Part 3 — Machine-readable verification results

```json
{
  "results": [
    {
      "name": "C-A1 ring visible above fold (bottom<=600)",
      "ok": true,
      "detail": "{\"id\":\"beatRing\",\"top\":316.3187561035156,\"bottom\":442.1187438964844,\"h\":125.79998779296875,\"w\":125.79999542236328,\"visible\":true}"
    },
    {
      "name": "C-A2 play/pause above fold (bottom<=600)",
      "ok": true,
      "detail": "{\"id\":\"btnPlayPause\",\"top\":530.734375,\"bottom\":590.734375,\"h\":60,\"w\":48,\"visible\":true}"
    },
    {
      "name": "C-A3 transport prev/replay/next above fold",
      "ok": true,
      "detail": ""
    },
    {
      "name": "C-A4 show-word control exists (>=48px)",
      "ok": true,
      "detail": ""
    },
    {
      "name": "C-A5 zero expanded 1-30 grids on idle screen",
      "ok": true,
      "detail": "drawer closed, board drawer closed"
    },
    {
      "name": "C-A6 30 chips live inside board drawer only",
      "ok": true,
      "detail": ""
    },
    {
      "name": "C-A7 light canvas",
      "ok": true,
      "detail": "rgb(248, 250, 252)"
    },
    {
      "name": "C-A8 dark canvas after one toggle",
      "ok": true,
      "detail": "rgb(15, 20, 32)"
    },
    {
      "name": "C-A9 drawer opens showing 1-30",
      "ok": true,
      "detail": ""
    },
    {
      "name": "S-B1 touch-drag across track leaves 5s",
      "ok": true,
      "detail": "5 -> 5"
    },
    {
      "name": "S-B2 range track is pointer-events:none",
      "ok": true,
      "detail": "none"
    },
    {
      "name": "S-B3 + stepper increments to 6s",
      "ok": true,
      "detail": "6"
    },
    {
      "name": "S-B4 - stepper decrements to 4s",
      "ok": true,
      "detail": "4"
    },
    {
      "name": "S-B5 programmatic dispatch sets 8s",
      "ok": true,
      "detail": "8"
    },
    {
      "name": "S-B6 output badge follows (8s)",
      "ok": true,
      "detail": "8s"
    },
    {
      "name": "T-C1 clean studio: no red dirty state",
      "ok": true,
      "detail": "{\"dirty\":null,\"btnDirty\":null,\"label\":\"Broadcast Current Pacing & Settings (Fas\"}"
    },
    {
      "name": "T-C2 one-word edit lights RED on both bars",
      "ok": true,
      "detail": "{\"bar\":\"true\",\"btn\":\"true\",\"ssb\":\"true\",\"pill\":\"30 / 30 Words Recognized \u2713 \u26a0\ufe0f 1 Word(s) Modified (\u201ccurious\u201d) \u2014 click Broadcast to Auto-Enrich & Sync\",\"label\":\"Broadcast Current Pacing & Settings (Fast Exa\"}"
    },
    {
      "name": "T-C3 pill names the modified word",
      "ok": true,
      "detail": "30 / 30 Words Recognized \u2713 \u26a0\ufe0f 1 Word(s) Modified (\u201ccurious\u201d) \u2014 click Broadcast to Auto-Enrich & Sync"
    },
    {
      "name": "T-C4 label keeps gate substring",
      "ok": true,
      "detail": "Broadcast Current Pacing & Settings (Fast Exa"
    },
    {
      "name": "T-C5 publish lands 4 files (session first, version last)",
      "ok": true,
      "detail": "data/session.json,data/config.json,data/elevenlabs-audio.json,data/version.json"
    },
    {
      "name": "T-C6 red cleared + emerald synced after publish",
      "ok": true,
      "detail": "{\"dirty\":null,\"synced\":\"true\",\"last\":\"Last synced to the class \u00b7 20:02 \u00b7 Rev #1793860000001\",\"state\":\"ok\"}"
    },
    {
      "name": "T-C7 last stamp shows Rev",
      "ok": true,
      "detail": "Last synced to the class \u00b7 20:02 \u00b7 Rev #1793860000001"
    },
    {
      "name": "T-C8 pill no longer warns after publish",
      "ok": true,
      "detail": "30 / 30 Words Recognized \u2713"
    },
    {
      "name": "T-C9 desktop 1440x900 dirty state red",
      "ok": true,
      "detail": "true"
    },
    {
      "name": "H-D1 toggle cycles light <-> dark only",
      "ok": true,
      "detail": "dark,light"
    },
    {
      "name": "H-D2 dark bg #0F1420",
      "ok": true,
      "detail": "rgb(15, 20, 32)"
    },
    {
      "name": "H-D3 light bg #F8FAFC",
      "ok": true,
      "detail": "rgb(248, 250, 252)"
    },
    {
      "name": "H-D4 brand contrast follows theme",
      "ok": true,
      "detail": "rgb(241, 245, 249) / rgb(15, 23, 42)"
    },
    {
      "name": "H-D5 settings shows 2 visible modes + hidden board",
      "ok": true,
      "detail": "[{\"v\":\"light\",\"hidden\":false},{\"v\":\"dark\",\"hidden\":false},{\"v\":\"board\",\"hidden\":true}]"
    },
    {
      "name": "W-E1 tab exit with dirty edits raises the guard modal",
      "ok": true,
      "detail": "true"
    },
    {
      "name": "V-E1 walkthrough mp4 rendered (24fps)",
      "ok": true,
      "detail": "212682B"
    }
  ]
}
```
