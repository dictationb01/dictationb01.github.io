# PRIORITY MATRIX — Smart Dictation Player v0.0.4.c → v0.0.5.c
## ප්‍රමුඛතා අවකාශය · වැදගත් කරුණු සහ අනවශ්‍ය කරුණු වෙන් කරගැනීම

**App**: Smart Dictation Player — CCBE Galle Branch · B1 English Class (Sri Lanka)
**Repo**: `dictationb1/dictationb1.github.io` @ `main` (audited at v0.0.4.c, build 2026-11-03)
**Method**: full-file audit of all 6 ES5 modules + index.html + sdp-ui.css + sw.js + 12 gates; headless-Chromium measurement of the live UI at 1440×900 and 390×844 (`03_visual_proofs/before/`, `work/metrics_before.json`).
**Credits**: Lecturer in Charge: Ms. Sumodya Sewmini · Creator: Hansana · Concept: Ayya01 (Lesandu)

---

## 1. Why the old concept failed — even after Morphe tokens · පරණ සංකල්පය අසාර්ථක වූ පෙදෙස

1. **Tokens are not a concept.** v0.0.4.c imported morphe-style materials (glass blur on chrome, `--shadow-btn`, spring easings) but kept the *information architecture* of v0.0.1: the Home screen is still a vertical stack of 7 competing grey cards with 3 redundant status paragraphs, and the cockpit still shows **47 buttons at once** during a listening beat (measured, desktop). A token layer cannot decide hierarchy — only a layout law can. · *ටෝකන් එකතු කිරීම යනු සංකල්පයක් නොවේ; තිරයේ අනුපිළිවෙල සහ පෙන්විය යුතු දේ තීරණය කරන්නේ පිරිසැලසුමයි.*
2. **No vibrancy, measured.** The whole Home screen renders **3 unique surface colours** — `#18181B`-ish zinc, one accent cyan, one dark chip (`metrics_before.json`, `surfaceColors`). The design brief calls for layered sapphire/indigo/emerald depth; the app ships flat monochrome slabs. · `වර්ණකමක් නැහැ` — මෙය දැන් මිනිත්තු කළ සත්‍යයක්: මුළු Home තිරයම පැතලි අළු පෘෂ්ඨ 3කි.*
3. **Invisible controls.** On the 30-Word list, the `Correct` mark buttons sit on a same-hue chip: contrast ratio **1.1** (WCAG floor is 4.5). A Sinhala cockpit chip renders at ratio 1.1 too. Students literally cannot see half the controls the UI offers. · *පෙනෙන්නම නැති බොත්තම්: `Correct` ලකුණු බොත්තම් 30ම contrast 1.1 — ඉඳහිට පෙනෙන නිසාම සිසුන්ට ඒවා භාවිත කරන්න බැහැ.*
4. **The cockpit is not a cockpit.** During dictation the student should look at ONE beat ring + ONE line of state. Today the player screen stacks: progress strip + pills drawer + cockpit card + hint chips + two transport decks + board bar — 47 buttons, 5 status paragraphs, and the hero transport deck is visually identical to the secondary deck (same 54px height, same chip styling). · *ක්‍රීඩා කාමරය කාමරයක් නොවේ — එක වචනයක් අහගෙන ලියන අවස්ථාවේ තිරයේ තිබෙන බොත්තම් 47ක් අතරේ ළමයි කුමන එකද කියලා හොයන්න වෙනවා.*
5. **The studio is a wall.** Unlocked Lecturer Studio renders 90 buttons, 17 status paragraphs, 3 surfaces (`metrics_before.json`). The PIN pad is fine (12 tactile keys), but past it the lecturer faces dense textarea/chip walls with no grouping rhythm. · *විවෘත කළ විට Studio එක බොත්තම් 90ක තොප්පියක්.*

---

## 2. The Matrix (P0 → P4)

### P0 — System contracts that must never break (release blockers)
| # | Contract | Why it is P0 |
|---|---|---|
| P0.1 | Zero ElevenLabs TTS credits; 100-clip Alice pack stays read-only (`data/elevenlabs-audio.json` untouched) | Iron Law #1 — any UI work that regenerates clips spends money and breaks G4/G11/G12 |
| P0.2 | Byte locks: `session.json` (55,260 B, SHA `1eaed80a…`), `gas-source.txt` (13,764 B, SHA `591b9b08…`), both Sinhala woff2 fonts, `data.html ≡ data/index.html`, `SDP_ENC_V2` vault + `pinVerifier` in `config.json` | Iron Law #2; SHA/byte assertions in G1/G4/G9 |
| P0.3 | Credits verbatim EN + SI in 6+ surfaces (`Ms. Sumodya Sewmini`, `Hansana`, `Ayya01 (Lesandu)`) | Iron Law #3; string-frozen by G1/G3/G7/G9/G12 |
| P0.4 | ES5 modules, ≤98,000 B CSS, ≤52,000 B index.html, 5-key localStorage law, 12/12 gates green, all gate-required DOM ids alive | Iron Law #4; the release gate itself |
| P0.5 | 4-path audio integrity: silent cold boot, `unlockAudio` never force-resumes, `playUrl().finish()` clears `src`+`load()`, `Studio.lock()` cancels speech | Zero ghost-voice regressions (G10/G12) |

### P1 — Dictation Cockpit & Active Listening (`#screen-player`) — the product's heart
**Essential (keep, elevate)**: beat ring + seconds + state line; one-line progress strip `WORD #N/30 · Repeat · Write`; paper-mode distraction-free stage; typing-mode inline input; Smart-Board projection bar; self-check results table.
**Clutter / broken (fix)**: two stacked transport decks with equal visual weight; 47 simultaneously visible buttons (target ≤ 12 primary + drawer); hint chips always visible even in paper mode; invisible controls (contrast 1.1); 5 competing status paragraphs; word-reveal bar clipping at 320px.
**Action**: one tactile transport deck (hero 72px play, 56px siblings, micro-captions), the second deck demoted into a 48px quiet row, hints auto-collapsed behind one chip in paper mode, ring/seconds as the single focal point, high-contrast `Correct/Missed` marks everywhere.

### P2 — Home Launchpad & Guided Onboarding (`#screen-home` + `#guideModal`)
**Essential**: hero card with session badge + primary CTA; mode picker (Paper/Typing); pacing presets; resume banner when a draft exists; credits footer (P0.3); honest sync badge.
**Clutter**: 7 grey cards of equal weight (journey card + quick practice + stats row all fight the hero); 3 status paragraphs that duplicate the badge; STEP cue strips that stay after first use; `CREDITS GOES TO Hansana` pill shouting at the top of the footer.
**Action**: vibrant 3-card bento (hero + study-deck + progress ring) with layered sapphire-indigo surfaces; status consolidated into one semantic pill row; cue texts retired after `cuesSeen` (already in settings — surface it); practice grid kept as the 4th card with real icon-tile styling.

### P3 — 30-Word Interactive Study Deck (`#screen-dict`) & Practice (`#screen-practice`)
**Essential**: search + filters (All 30 / Weak / Mastered); word rows with EN headword, `/IPA/`, POS badge, Sinhala meaning, example with highlighted hit; 1-tap Alice voice; mastered/weak toggles.
**Clutter/broken**: 30 identical flat rows — no hierarchy between headword and meaning (measured: 30 low-contrast texts, ratio 1.1 on the mark buttons); the "Correct" action invisible; rows are dense walls of 5 font sizes with no anchor.
**Action**: Quizlet-style two-line cards — headword + IPA on the anchor line (high contrast), Sinhala meaning + POS chip on the second line, example sentence with highlighted `<b class="d-hit">`, play button as a 48px circular icon-button on the right, state-coloured left rail (mastered=emerald, weak=amber).

### P4 — Settings & Lecturer Studio (`#screen-settings` + `#screen-studio`)
**Essential (keep)**: 5 numbered setting groups; pacing presets row; the tactile PIN pad (12 keys, 56px); the 3-card unlocked console structure (words → settings → keys) with the 4-step master list; sync broadcast bar; vault badge.
**Clutter**: raw form-dump styling (inputs with no group surface); 17 status paragraphs in studio; quota/diagnostic rows always visible even when idle; `.set-card` headers as tiny 13px text.
**Action**: iOS/Linear-style grouped cards with 15px section headers, 48px controls (already gated), status lines collapsed into one live pill per card, studio cards get real header rhythm (icon + title + state dot) — all with zero structural DOM change (studio markup is JS-generated; CSS-only restyle).

### P5 — Non-visual engineering hygiene (queued, not this release)
README/doc drift (ARCHITECTURE_MAP 57,381 B claim vs real 55,260 B), CHANGELOG headroom (1,122 B), morphe accordion hook dormant (matches no `details` element today), `guideLangPill` inside modal vs header duplication. These stay documented here and are NOT addressed in v0.0.5.c to keep the diff surface minimal.

---

## 3. Essential vs clutter — the separation rule · වෙන් කරගැනීමේ නීතිය

**Rule 1 — One job per screen.** Every element either drives the current action or it is demoted (drawer, quiet row, `hidden`). No third state.
**Rule 2 — Gate IDs are never deleted.** A demoted control keeps its node in the DOM (G1 reads raw `id="…"` substrings; runtime gates need it findable). Visually consolidated = `hidden` or re-parented into a drawer — never removed.
**Rule 3 — Contrast floor 4.5:1.** Every interactive label must clear WCAG AA on its own surface. The v0.0.5.c CSS enforces accent-ink pairs instead of same-hue-on-same-hue.
**Rule 4 — Beat first.** In the cockpit, the ring + seconds + one state line own ≥80% of the visual weight. Everything else is smaller, quieter, or hidden.
**Rule 5 — Zero cost.** All of this is CSS + index.html markup restructuring; the 6 JS modules, the 100-clip pack, and the vault are untouched (P0.1/P0.2).

---

## 4. Measured baseline → targets

| Metric (desktop, dark) | v0.0.4.c (measured) | v0.0.5.c target |
|---|---|---|
| Player cockpit visible buttons | 47 | ≤ 26 incl. pills drawer closed state; transport decks 2→1+quiet row |
| Player status paragraphs | 5 | 2 (beat line + one pill row) |
| Home unique surfaces | 3 | ≥ 6 (canvas / card / elevated / interactive / accent glass / sunken) |
| Home card weight spread | 7 equal cards | 1 hero + 3 bento + quiet footer |
| Word list low-contrast texts | 30 (ratio 1.1) | 0 (4.5:1 floor) |
| Studio buttons / status paras | 90 / 17 | unchanged count (JS-generated) but grouped into 3 cards with visible hierarchy + 48px targets |
| Touch targets < 44px | 0 (48px floor already gated) | 0 (keep) |
| Horizontal overflow 320–1440px | 0 (keep) | 0 (keep) |
| Gates | 12/12 PASS | 12/12 PASS, 0 FAIL |
| CSS size | 97,804 / 98,000 B (196 B headroom) | ≤ 98,000 B (rewrite in place, leaner selectors) |
| ElevenLabs credits spent | 0 | 0 |

---

## 5. Release-literal bump plan (0.0.4.c → 0.0.5.c)

The version literal is pinned in 7 shipped surfaces AND in 11 test files (G1–G12 re-pin in lockstep, as this repo's own history does for every release). v0.0.5.c surfaces: `index.html` (`var TARGET`, `#sdpVerPill`, meta description), `data.html` + `data/index.html` (byte-identical pair, TARGET + pill), `sw.js` (`sdp-v0.0.5.c-s15` shell + `PRESERVE_CACHES=[]` + `sdp-youdao-v1`/`sdp-audio-clips` kept), `manifest.webmanifest` (3× `?v=0.0.5.c`, start_url), `data/version.json` (`appVersion/version '0.0.5.c'`, buildDate `2026-11-04`, schema 15, settingsRev 30, syncRev 1793740000001), `data/config.json` (header row), `data/elevenlabs-audio.json` (header row), `data/data-meter.js` (`CACHE_VERSION 'sdp-v0.0.5.c'`), `data/sdp-data-sync.js` (`'0.0.5.c'`, `SDP.ver=15`, `SETTINGS_REV=30`), `data/sdp-ui-views.js` (`APP_VERSION`, `aboutVersion` text), `data/studio.js` (`SDP.version` ref), tests: guide seeds in `phase1/browser/e2e/voice-guide/studio-safety/vault-sync` (0.0.5.c), `upgrade-browser` `SHELL`, `check/server/audit/upgrade.test` literal rows, `live-lab` derives from index.html (no edit needed), plus `docs/` ledger entry. `syncRev` must move forward strictly (`1793740000001 > 1793740000000`).
