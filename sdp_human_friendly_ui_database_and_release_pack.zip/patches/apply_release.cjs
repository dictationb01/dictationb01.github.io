#!/usr/bin/env node
'use strict';
/* apply_release.cjs — v0.0.5.c "Sapphire Ladder" deterministic installer.
 * Usage: node patches/apply_release.cjs <repoRoot>   (default: cwd)
 * Copies repo_full_tree/ over the repo, then verifies in one pass:
 * 4 SHA-256 byte locks, data.html == data/index.html, SESSION_BYTES == live size,
 * wOF2 magic on both fonts, and the 0.0.5.c literal agreement on 8 surfaces. */

var fs = require('fs');
var path = require('path');
var crypto = require('crypto');

var ROOT = path.resolve(process.argv[2] || process.cwd());
var PACK = path.resolve(__dirname, '..', 'repo_full_tree');
var fails = [];

var LOCKS = {
  'data/session.json': '1eaed80a290be4ef527b6a4c112cdb51419ea74c11f4e9ee37ad94bc7e79fef8',
  'data/gas-source.txt': '591b9b086f6d3723afb2604a837ffc495c69a481c490f11e58131c2222b0981e',
  'assets/fonts/NotoSansSinhala-Regular.woff2': '23f1503e1e75413903dff05f4415f59d4b903cfeb2a8d1c0047ac158d20ff280',
  'assets/fonts/NotoSansSinhala-Bold.woff2': 'bf59c1487b0a88a07a678190fd7a6e93aa01c5ec3f3f2f9e349922ac944a643e'
};
var LITERAL_SURFACES = ['index.html', 'data.html', 'data/index.html', 'sw.js',
  'manifest.webmanifest', 'data/version.json', 'data/config.json', 'data/data-meter.js'];

function walk(dir, cb) {
  fs.readdirSync(dir).forEach(function (name) {
    var p = path.join(dir, name);
    var st = fs.lstatSync(p);
    if (st.isDirectory()) walk(p, cb);
    else cb(p);
  });
}

function copyAll() {
  var n = 0;
  walk(PACK, function (f) {
    var rel = path.relative(PACK, f);
    var dst = path.join(ROOT, rel);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(f, dst);
    n++;
  });
  console.log('copied ' + n + ' files from repo_full_tree/');
}

function verify() {
  Object.keys(LOCKS).forEach(function (rel) {
    var p = path.join(ROOT, rel);
    var got = crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
    if (got !== LOCKS[rel]) fails.push(rel + ' SHA mismatch: ' + got);
  });
  console.log('SHA-256 byte locks: 4/4 verified');

  var a = fs.readFileSync(path.join(ROOT, 'data.html'));
  var b = fs.readFileSync(path.join(ROOT, 'data/index.html'));
  if (!a.equals(b)) fails.push('data.html != data/index.html');
  console.log('data.html pair: identical (' + a.length + ' bytes)');

  var live = fs.statSync(path.join(ROOT, 'data/session.json')).size;
  var html = a.toString('utf8');
  var m = /var SESSION_BYTES = (\d+);/.exec(html);
  if (!m || Number(m[1]) !== live) fails.push('SESSION_BYTES ' + (m ? m[1] : '?') + ' != live ' + live);
  console.log('SESSION_BYTES: ' + live + ' matches live session.json');

  ['Regular', 'Bold'].forEach(function (w) {
    var head = fs.readFileSync(path.join(ROOT, 'assets/fonts/NotoSansSinhala-' + w + '.woff2')).slice(0, 4).toString('latin1');
    if (head !== 'wOF2') fails.push('font ' + w + ' magic != wOF2');
  });
  console.log('wOF2 magic: both fonts verified');

  LITERAL_SURFACES.forEach(function (rel) {
    var s = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    if (s.indexOf('0.0.5.c') === -1) fails.push(rel + ' missing 0.0.5.c literal');
  });
  console.log('0.0.5.c literal agreement: ' + LITERAL_SURFACES.length + '/' + LITERAL_SURFACES.length + ' surfaces');

  var eleven = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/elevenlabs-audio.json'), 'utf8'));
  if (eleven.voiceId !== 'Xb7hH8MSUJpSbSDYk0k2' || eleven.voiceName !== 'Alice' || eleven.modelId !== 'eleven_flash_v2_5') {
    fails.push('Alice identity strings changed');
  }
  console.log('Alice pack identity: voiceId/voiceName/modelId intact (' + Object.keys(eleven.clips || {}).length + ' clips read-only)');
}

try {
  if (!fs.existsSync(PACK)) throw new Error('repo_full_tree/ not found next to patches/');
  copyAll();
  verify();
} catch (e) {
  fails.push(String(e.message || e));
}

if (fails.length) {
  console.error('RELEASE VERIFICATION FAILED:\n  ' + fails.join('\n  '));
  process.exit(1);
}
console.log('RELEASE APPLIED AND VERIFIED');
